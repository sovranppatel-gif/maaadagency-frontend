import type { Metadata } from "next";
import { Archivo, Inter } from "next/font/google";
import { site } from "@/data/site";
import "./globals.css";

const archivo = Archivo({
  variable: "--font-archivo",
  subsets: ["latin"],
  weight: ["600", "700", "800", "900"],
  display: "swap",
});

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: "Maa Ad Agency | 360° Advertising & Branding Solutions",
    template: `%s | ${site.name}`,
  },
  description:
    "Maa Ad Agency provides 360° advertising, branding, outdoor advertising, print, digital marketing, LED screens, promotional vans and event solutions.",
  keywords: [
    "Maa Ad Agency",
    "advertising agency Raipur",
    "outdoor advertising Chhattisgarh",
    "LED van advertising",
    "digital wall painting",
    "branding agency Raipur",
    "print media advertising",
  ],
  authors: [{ name: site.name }],
  openGraph: {
    type: "website",
    locale: "en_IN",
    url: site.url,
    siteName: site.name,
    title: "Maa Ad Agency | 360° Advertising & Branding Solutions",
    description:
      "A 360° advertising agency for a stronger, brighter and bolder tomorrow — print, digital, outdoor and on-ground brand experiences that get you noticed.",
    images: [{ url: "/images/logo.png", width: 1200, height: 630, alt: site.name }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Maa Ad Agency | 360° Advertising & Branding Solutions",
    description:
      "A 360° advertising agency for a stronger, brighter and bolder tomorrow.",
    images: ["/images/logo.png"],
  },
  icons: {
    icon: "/icon.png",
    apple: "/apple-icon.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${archivo.variable} ${inter.variable}`}>
      <body className="min-h-screen bg-white font-sans text-brand-dark antialiased">
        {children}
      </body>
    </html>
  );
}
