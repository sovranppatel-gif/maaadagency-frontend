"use client";

import { useMemo } from "react";
import { Card, CardHeader } from "@/components/master-admin/ui/Card";
import { StatCard } from "@/components/master-admin/StatCard";
import { BarChart } from "@/components/master-admin/charts/BarChart";
import { DonutChart } from "@/components/master-admin/charts/DonutChart";
import { LineChart } from "@/components/master-admin/charts/LineChart";
import { leads } from "@/lib/mock-data/leads";
import { works } from "@/lib/mock-data/works";
import { employees } from "@/lib/mock-data/employees";
import { conversations } from "@/lib/mock-data/whatsapp";
import { Inbox, TrendingUp, Users, MessageCircle } from "lucide-react";

const sourceColors: Record<string, string> = {
  WhatsApp: "#25D366",
  Website: "#C5161D",
  Referral: "#7c3aed",
  Manual: "#a3a3a3",
};

const monthlyLeads = [
  { label: "Apr", value: 18 },
  { label: "May", value: 22 },
  { label: "Jun", value: 27 },
  { label: "Jul", value: 24 },
  { label: "Aug", value: 31 },
  { label: "Sep", value: 20 },
];

const monthlyCompleted = [
  { label: "Apr", value: 12 },
  { label: "May", value: 16 },
  { label: "Jun", value: 19 },
  { label: "Jul", value: 21 },
  { label: "Aug", value: 26 },
  { label: "Sep", value: 15 },
];

const whatsappTrend = [
  { label: "Mon", value: 62 },
  { label: "Tue", value: 74 },
  { label: "Wed", value: 58 },
  { label: "Thu", value: 81 },
  { label: "Fri", value: 94 },
  { label: "Sat", value: 47 },
  { label: "Sun", value: 33 },
];

export default function AnalyticsPage() {
  const leadsByService = useMemo(() => {
    const map = new Map<string, number>();
    leads.forEach((l) => map.set(l.service, (map.get(l.service) || 0) + 1));
    return Array.from(map.entries())
      .map(([label, value]) => ({ label, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 8);
  }, []);

  const leadsBySource = useMemo(() => {
    const map = new Map<string, number>();
    leads.forEach((l) => map.set(l.source, (map.get(l.source) || 0) + 1));
    return Array.from(map.entries()).map(([label, value]) => ({ label, value, color: sourceColors[label] || "#999" }));
  }, []);

  const workByStatus = useMemo(() => {
    const map = new Map<string, number>();
    works.forEach((w) => map.set(w.status, (map.get(w.status) || 0) + 1));
    const colors: Record<string, string> = {
      UNASSIGNED: "#a3a3a3",
      ASSIGNED: "#7c3aed",
      IN_PROGRESS: "#f59e0b",
      SUBMITTED: "#06b6d4",
      CHANGES_REQUESTED: "#f97316",
      APPROVED: "#10b981",
      COMPLETED: "#111111",
    };
    return Array.from(map.entries()).map(([label, value]) => ({ label: label.replace("_", " "), value, color: colors[label] || "#999" }));
  }, []);

  const employeePerformance = useMemo(
    () =>
      employees
        .map((e) => ({ label: e.name.split(" ")[0], value: e.completedWorks }))
        .sort((a, b) => b.value - a.value)
        .slice(0, 6),
    []
  );

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon={Inbox} label="Total Leads (YTD)" value={leads.length * 9} tone="red" index={0} change={{ value: "14%", positive: true }} />
        <StatCard icon={TrendingUp} label="Conversion Rate" value="46%" index={1} change={{ value: "3%", positive: true }} />
        <StatCard icon={Users} label="Avg. Completion Time" value="6.4 days" index={2} change={{ value: "0.8d", positive: true }} />
        <StatCard icon={MessageCircle} label="WhatsApp Response Rate" value="98%" index={3} change={{ value: "1%", positive: true }} />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader title="Leads by Service" subtitle="Which services generate the most enquiries" />
          <BarChart data={leadsByService} />
        </Card>
        <Card>
          <CardHeader title="Leads by Source" subtitle="Where your leads are coming from" />
          <DonutChart data={leadsBySource} />
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader title="Work Status Breakdown" subtitle="Current state of all work items" />
          <DonutChart data={workByStatus} />
        </Card>
        <Card>
          <CardHeader title="Employee Performance" subtitle="Completed work items per employee" />
          <BarChart data={employeePerformance} color="#111111" />
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card>
          <CardHeader title="Monthly Leads" />
          <LineChart data={monthlyLeads} />
        </Card>
        <Card>
          <CardHeader title="Monthly Completed Work" />
          <LineChart data={monthlyCompleted} color="#10b981" />
        </Card>
        <Card>
          <CardHeader title="WhatsApp Conversations" subtitle="This week" />
          <LineChart data={whatsappTrend} color="#25D366" />
          <p className="mt-2 text-xs text-neutral-400">{conversations.length} active conversations total</p>
        </Card>
      </div>
    </div>
  );
}
