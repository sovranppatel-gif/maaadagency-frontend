"use client";

import { useEffect, useMemo, useState } from "react";
import { Bot, Inbox as InboxIcon } from "lucide-react";
import { ConversationList } from "@/components/master-admin/whatsapp/ConversationList";
import { ChatWindow } from "@/components/master-admin/whatsapp/ChatWindow";
import { ClientDetailsPanel } from "@/components/master-admin/whatsapp/ClientDetailsPanel";
import { BotFlowPanel } from "@/components/master-admin/whatsapp/BotFlowPanel";
import { AssignmentModal } from "@/components/master-admin/AssignmentModal";
import { useToast } from "@/components/master-admin/ui/ToastProvider";
import { getConversations, getMessages, sendMessage, markConversationRead } from "@/lib/api/whatsapp";
import { assignLead } from "@/lib/api/leads";
import { conversations as conversationsStore } from "@/lib/mock-data/whatsapp";
import type { ConversationFilter, WhatsAppConversation, WhatsAppMessage } from "@/lib/types";
import { cn } from "@/lib/utils";

type MobileView = "list" | "chat" | "details";

export default function WhatsAppInboxPage() {
  const [tab, setTab] = useState<"inbox" | "bot">("inbox");
  const [conversations, setConversations] = useState<WhatsAppConversation[]>([]);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<ConversationFilter>("All");
  const [activeId, setActiveId] = useState<string | undefined>();
  const [messages, setMessages] = useState<WhatsAppMessage[]>([]);
  const [mobileView, setMobileView] = useState<MobileView>("list");
  const [assignOpen, setAssignOpen] = useState(false);
  const { push } = useToast();

  useEffect(() => {
    getConversations(filter, search).then((data) => {
      setConversations(data);
      if (!activeId && data[0]) setActiveId(data[0].id);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter, search]);

  useEffect(() => {
    if (!activeId) return;
    getMessages(activeId).then(setMessages);
    markConversationRead(activeId).then(() => {
      setConversations((prev) => prev.map((c) => (c.id === activeId ? { ...c, unreadCount: 0 } : c)));
    });
  }, [activeId]);

  const active = useMemo(() => conversations.find((c) => c.id === activeId) ?? null, [conversations, activeId]);

  function selectConversation(c: WhatsAppConversation) {
    setActiveId(c.id);
    setMobileView("chat");
  }

  async function handleSend(text: string) {
    if (!activeId) return;
    const msg = await sendMessage(activeId, text);
    setMessages((prev) => [...prev, msg]);
    setConversations((prev) =>
      prev.map((c) => (c.id === activeId ? { ...c, lastMessage: text, lastMessageAt: msg.timestamp } : c))
    );
  }

  async function handleAssign(employeeId: string) {
    if (!active?.leadId) {
      push({ kind: "info", title: "No linked lead", description: "This conversation isn't linked to a lead yet." });
      return;
    }
    const updated = await assignLead(active.leadId, employeeId);
    if (updated) {
      const conv = conversationsStore.find((c) => c.id === active.id);
      if (conv) conv.assignedEmployeeId = employeeId;
      setConversations((prev) => prev.map((c) => (c.id === active.id ? { ...c, assignedEmployeeId: employeeId } : c)));
      push({ kind: "success", title: "Employee assigned" });
    }
  }

  return (
    <div className="flex h-[calc(100vh-6rem)] flex-col gap-4">
      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => setTab("inbox")}
          className={cn(
            "flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-bold transition-colors",
            tab === "inbox" ? "bg-brand-red text-white" : "bg-white text-neutral-500 hover:bg-neutral-100"
          )}
        >
          <InboxIcon className="h-4 w-4" />
          Inbox
        </button>
        <button
          type="button"
          onClick={() => setTab("bot")}
          className={cn(
            "flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-bold transition-colors",
            tab === "bot" ? "bg-brand-red text-white" : "bg-white text-neutral-500 hover:bg-neutral-100"
          )}
        >
          <Bot className="h-4 w-4" />
          Bot Flow
        </button>
      </div>

      {tab === "bot" ? (
        <div className="flex-1 overflow-y-auto">
          <BotFlowPanel />
        </div>
      ) : (
        <div className="grid flex-1 grid-cols-1 overflow-hidden rounded-2xl border border-black/6 bg-white shadow-sm lg:grid-cols-[320px_1fr_320px]">
          <div className={cn("min-h-0 border-black/6 lg:block lg:border-r", mobileView === "list" ? "block" : "hidden")}>
            <ConversationList
              conversations={conversations}
              activeId={activeId}
              onSelect={selectConversation}
              search={search}
              onSearch={setSearch}
              filter={filter}
              onFilter={setFilter}
            />
          </div>
          <div className={cn("min-h-0 lg:block", mobileView === "chat" ? "block" : "hidden")}>
            <ChatWindow
              conversation={active}
              messages={messages}
              onSend={handleSend}
              onBack={() => setMobileView("list")}
              onShowDetails={() => setMobileView("details")}
            />
          </div>
          <div className={cn("min-h-0 border-black/6 lg:block lg:border-l", mobileView === "details" ? "block" : "hidden")}>
            <ClientDetailsPanel conversation={active} onBack={() => setMobileView("chat")} onAssign={() => setAssignOpen(true)} />
          </div>
        </div>
      )}

      <AssignmentModal
        open={assignOpen}
        onClose={() => setAssignOpen(false)}
        title="Assign Conversation"
        description={active ? `Assign ${active.clientName}'s requirement to an employee.` : undefined}
        onAssign={handleAssign}
      />
    </div>
  );
}
