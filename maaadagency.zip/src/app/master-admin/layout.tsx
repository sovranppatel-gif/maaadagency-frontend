import type { Metadata } from "next";
import { AdminShell } from "@/components/master-admin/AdminShell";

export const metadata: Metadata = {
  title: {
    default: "Master Admin | Maa Ad Agency",
    template: "%s | Master Admin",
  },
  robots: { index: false, follow: false },
};

export default function MasterAdminLayout({ children }: { children: React.ReactNode }) {
  return <AdminShell>{children}</AdminShell>;
}
