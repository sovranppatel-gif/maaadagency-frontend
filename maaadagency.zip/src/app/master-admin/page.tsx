"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Inbox, Sparkles, Activity, Clock, CheckCircle2, Users, MessageCircle, Plus } from "lucide-react";
import { StatCard } from "@/components/master-admin/StatCard";
import { WorkflowPanel } from "@/components/master-admin/WorkflowPanel";
import { WhatsAppOverviewCard } from "@/components/master-admin/WhatsAppOverviewCard";
import { LeadTable } from "@/components/master-admin/LeadTable";
import { AssignmentModal } from "@/components/master-admin/AssignmentModal";
import { Card, CardHeader } from "@/components/master-admin/ui/Card";
import { useToast } from "@/components/master-admin/ui/ToastProvider";
import { getLeads, assignLead } from "@/lib/api/leads";
import { employees } from "@/lib/mock-data/employees";
import { conversations } from "@/lib/mock-data/whatsapp";
import { works } from "@/lib/mock-data/works";
import { getEmployeeById } from "@/lib/mock-data/employees";
import type { Lead } from "@/lib/types";

export default function DashboardPage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [assignTarget, setAssignTarget] = useState<Lead | null>(null);
  const { push } = useToast();

  useEffect(() => {
    getLeads().then((data) => {
      setLeads(data);
      setLoading(false);
    });
  }, []);

  const newLeads = leads.filter((l) => l.status === "New").length;
  const activeWork = works.filter((w) => w.status === "IN_PROGRESS" || w.status === "ASSIGNED").length;
  const pendingReview = works.filter((w) => w.status === "SUBMITTED" || w.status === "CHANGES_REQUESTED").length;
  const completed = works.filter((w) => w.status === "COMPLETED").length;
  const whatsappChats = conversations.length;

  async function handleAssign(employeeId: string) {
    if (!assignTarget) return;
    const updated = await assignLead(assignTarget.id, employeeId);
    if (updated) {
      setLeads((prev) => prev.map((l) => (l.id === updated.id ? updated : l)));
      const emp = getEmployeeById(employeeId);
      push({ kind: "success", title: "Lead assigned", description: `${assignTarget.clientName} assigned to ${emp?.name}.` });
    }
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7">
        <StatCard icon={Inbox} label="Total Leads" value={leads.length || 128} tone="red" href="/master-admin/leads" index={0} change={{ value: "12%", positive: true }} />
        <StatCard icon={Sparkles} label="New Leads" value={newLeads || 24} href="/master-admin/leads?status=New" index={1} change={{ value: "8%", positive: true }} />
        <StatCard icon={Activity} label="Active Work" value={activeWork || 37} href="/master-admin/work" index={2} change={{ value: "4%", positive: true }} />
        <StatCard icon={Clock} label="Pending Review" value={pendingReview || 8} href="/master-admin/work?status=SUBMITTED" index={3} change={{ value: "2%", positive: false }} />
        <StatCard icon={CheckCircle2} label="Completed" value={completed || 59} href="/master-admin/work?status=COMPLETED" index={4} change={{ value: "19%", positive: true }} />
        <StatCard icon={Users} label="Employees" value={employees.length} href="/master-admin/employees" index={5} />
        <StatCard icon={MessageCircle} label="WhatsApp Chats" value={whatsappChats} href="/master-admin/whatsapp" index={6} change={{ value: "6%", positive: true }} />
      </div>

      <WorkflowPanel leads={leads} />

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <div className="xl:col-span-2">
          <Card>
            <CardHeader
              title="Recent Leads"
              subtitle="Newest enquiries across WhatsApp, website and manual entry."
              action={
                <Link
                  href="/master-admin/leads"
                  className="rounded-lg border border-black/10 px-3 py-1.5 text-xs font-bold text-neutral-600 hover:bg-neutral-50"
                >
                  View All
                </Link>
              }
            />
            {loading ? (
              <div className="py-16 text-center text-sm text-neutral-400">Loading leads…</div>
            ) : (
              <LeadTable leads={leads.slice(0, 6)} compact onAssign={setAssignTarget} />
            )}
          </Card>
        </div>
        <WhatsAppOverviewCard messagesToday={94} activeChats={conversations.filter((c) => c.status !== "Completed").length} newLeads={newLeads} unread={conversations.reduce((a, c) => a + c.unreadCount, 0)} />
      </div>

      <Link
        href="/master-admin/work"
        className="fixed bottom-6 right-6 z-30 flex h-12 w-12 items-center justify-center rounded-full bg-brand-red text-white shadow-xl shadow-brand-red/30 transition-transform hover:scale-105 lg:hidden"
        aria-label="Create work"
      >
        <Plus className="h-5 w-5" />
      </Link>

      <AssignmentModal
        open={!!assignTarget}
        onClose={() => setAssignTarget(null)}
        title="Assign Lead"
        description={assignTarget ? `Assign ${assignTarget.clientName}'s requirement to an employee.` : undefined}
        onAssign={handleAssign}
      />
    </div>
  );
}
