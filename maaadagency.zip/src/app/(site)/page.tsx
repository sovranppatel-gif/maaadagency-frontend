import { Hero } from "@/components/sections/Hero";
import { TrustedBrands } from "@/components/sections/TrustedBrands";
import { About } from "@/components/sections/About";
import { Services } from "@/components/sections/Services";
import { FeaturedService } from "@/components/sections/FeaturedService";
import { OutdoorAdvertising } from "@/components/sections/OutdoorAdvertising";
import { PrintDigital } from "@/components/sections/PrintDigital";
import { Portfolio } from "@/components/sections/Portfolio";
import { ProjectShowcase } from "@/components/sections/ProjectShowcase";
import { WhyChooseUs } from "@/components/sections/WhyChooseUs";
import { Testimonials } from "@/components/sections/Testimonials";
import { CTA } from "@/components/sections/CTA";
import { Contact } from "@/components/sections/Contact";

export default function Home() {
  return (
    <>
      <Hero />
      <TrustedBrands />
      <About />
      <Services />
      <FeaturedService />
      <OutdoorAdvertising />
      <PrintDigital />
      <Portfolio />
      <ProjectShowcase />
      <WhyChooseUs />
      <Testimonials />
      <CTA />
      <Contact />
    </>
  );
}
