import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { FloatingActions } from "@/components/layout/FloatingActions";
import { MobileStickyBar } from "@/components/layout/MobileStickyBar";
import { Preloader } from "@/components/layout/Preloader";

// The public marketing site's shell (navbar, footer, floating actions).
// Kept in its own route group so /master-admin can use a completely
// different app shell without inheriting any of this.
export default function SiteLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <Preloader />
      <Navbar />
      <main className="flex-1 pb-16 sm:pb-0">{children}</main>
      <Footer />
      <FloatingActions />
      <MobileStickyBar />
    </div>
  );
}
