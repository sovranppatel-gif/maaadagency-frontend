import {
  Lightbulb,
  Target,
  Workflow,
  Radio,
  MapPinned,
  HeartHandshake,
  type LucideIcon,
} from "lucide-react";

export const whyChooseUsStats = [
  { value: 15, suffix: "+", label: "Years of Experience" },
  { value: 100, suffix: "+", label: "Trusted Brands" },
  { value: 1000, suffix: "+", label: "Campaigns Delivered" },
  { value: 360, suffix: "°", label: "Advertising Solutions" },
];

export type WhyPoint = {
  icon: LucideIcon;
  title: string;
  description: string;
};

export const whyPoints: WhyPoint[] = [
  {
    icon: Lightbulb,
    title: "Creative Thinking",
    description: "Bold, original ideas crafted to make your brand stand out.",
  },
  {
    icon: Target,
    title: "Strategic Planning",
    description: "Campaigns built on insight, not guesswork.",
  },
  {
    icon: Workflow,
    title: "End-to-End Execution",
    description: "From concept to on-ground delivery, fully managed.",
  },
  {
    icon: Radio,
    title: "Multi-Channel Advertising",
    description: "Print, digital, outdoor and on-ground, working together.",
  },
  {
    icon: MapPinned,
    title: "Local & Regional Reach",
    description: "Deep on-ground presence across Chhattisgarh and beyond.",
  },
  {
    icon: HeartHandshake,
    title: "Client-Focused Approach",
    description: "Your goals drive every decision we make.",
  },
];
