export const printServices = [
  "Flex Printing",
  "Offset Printing",
  "Pamphlets",
  "Visiting Cards",
  "Brochures",
  "Calendars",
  "Stickers",
];

export const digitalServices = [
  "Social Media Marketing",
  "Content Marketing",
  "Email Marketing",
  "Digital Campaigns",
  "SEO",
  "Brand Strategy",
];
