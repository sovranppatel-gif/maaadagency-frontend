export const site = {
  name: "Maa Ad Agency",
  tagline: "Turn Ideas Into Impact",
  url: "https://www.maaadagency.com",
  founded: 2010,
  phones: ["79743 51591", "78691 87165"],
  email: "info@maaadagency.com",
  website: "www.maaadagency.com",
  address: {
    line1: "Manjeet Tower, Near Raipura Chowk,",
    line2: "Raipur (C.G.)",
  },
  registrationOffice: {
    line1: "Ring Road No. 1,",
    line2: "Near Kushalpur Chowk, Raipur (C.G.)",
  },
  social: {
    instagram: "https://instagram.com/maaadagency",
    facebook: "https://facebook.com/maaadagency",
    linkedin: "https://linkedin.com/company/maaadagency",
    youtube: "https://youtube.com/@maaadagency",
  },
};

export const navLinks = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Work", href: "#work" },
  { label: "Clients", href: "#clients" },
  { label: "Contact", href: "#contact" },
];

export const heroStats = [
  { value: 15, suffix: "+", label: "Years of Experience" },
  { value: 100, suffix: "+", label: "Trusted Brands" },
  { value: 1000, suffix: "+", label: "Successful Campaigns" },
  { value: 360, suffix: "°", label: "Advertising Solutions" },
];
