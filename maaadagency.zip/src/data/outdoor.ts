export type OutdoorItem = {
  image: string;
  title: string;
  tag: string;
};

export const outdoorGallery: OutdoorItem[] = [
  {
    image: "/images/work/promo-van-paint.jpg",
    title: "Promotional Van",
    tag: "Nippon Paint · Raipur",
  },
  {
    image: "/images/work/promo-van-bike.jpg",
    title: "Promotional Van",
    tag: "Bajaj · Dhamtari",
  },
  {
    image: "/images/work/digital-wall-painting.jpg",
    title: "Digital Wall Painting",
    tag: "Muthoot Finance · Ambikapur",
  },
  {
    image: "/images/work/led-screen-entrance.jpg",
    title: "LED Screen",
    tag: "Raipur City Center Mall",
  },
  {
    image: "/images/work/led-screen-foodcourt.jpg",
    title: "LED Screen",
    tag: "Raipur City Center Mall",
  },
];

export const featuredVan = {
  image: "/images/work/led-van.jpg",
  title: "Hydraulic LED Van",
  description:
    "Take your brand directly to your audience with high-impact mobile LED advertising.",
  features: [
    "Outdoor Advertising",
    "Moving LED Screen",
    "Audio Announcements",
    "On-Ground Engagement",
    "High Visibility",
    "Local & Regional Campaigns",
  ],
};
