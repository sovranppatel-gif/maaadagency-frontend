export type PortfolioCategory =
  | "Outdoor"
  | "Print"
  | "Digital"
  | "Events"
  | "Van Branding"
  | "LED";

export type PortfolioItem = {
  image: string;
  title: string;
  location?: string;
  categories: PortfolioCategory[];
};

export const portfolioFilters: ("All" | PortfolioCategory)[] = [
  "All",
  "Outdoor",
  "Print",
  "Digital",
  "Events",
  "Van Branding",
  "LED",
];

export const portfolio: PortfolioItem[] = [
  {
    image: "/images/work/led-van.jpg",
    title: "Hydraulic LED Van Campaign — BNI",
    location: "Raipur, C.G.",
    categories: ["LED", "Van Branding", "Outdoor"],
  },
  {
    image: "/images/work/led-screen-entrance.jpg",
    title: "Mall Entrance LED Display",
    location: "Raipur City Center Mall",
    categories: ["LED"],
  },
  {
    image: "/images/work/led-screen-foodcourt.jpg",
    title: "Food Court LED Display",
    location: "Raipur City Center Mall",
    categories: ["LED"],
  },
  {
    image: "/images/work/promo-van-paint.jpg",
    title: "Nippon Paint Van Promotion",
    location: "Raipur, C.G.",
    categories: ["Van Branding", "Outdoor"],
  },
  {
    image: "/images/work/promo-van-bike.jpg",
    title: "Bajaj Two-Wheeler Van Promotion",
    location: "Dhamtari, C.G.",
    categories: ["Van Branding", "Outdoor"],
  },
  {
    image: "/images/work/digital-wall-painting.jpg",
    title: "Muthoot Finance Wall Branding",
    location: "Ambikapur, C.G.",
    categories: ["Outdoor", "Digital"],
  },
  {
    image: "/images/work/offset-press.jpg",
    title: "Offset Printing Production",
    location: "Raipur, C.G.",
    categories: ["Print"],
  },
  {
    image: "/images/work/flex-printer.jpg",
    title: "Large Format Flex Printing",
    location: "Raipur, C.G.",
    categories: ["Print"],
  },
  {
    image: "/images/work/flex-printer-operator.jpg",
    title: "Digital Wall Print Production",
    location: "Ambikapur, C.G.",
    categories: ["Print", "Digital"],
  },
  {
    image: "/images/work/event-management.jpg",
    title: "Event Design & Styling",
    categories: ["Events"],
  },
];
