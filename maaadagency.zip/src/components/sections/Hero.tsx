"use client";

import Image from "next/image";
import { motion, useReducedMotion } from "motion/react";
import { ArrowRight, Play, Sparkles, TrendingUp } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { MagneticButton } from "@/components/ui/MagneticButton";
import { AnimatedCounter } from "@/components/ui/AnimatedCounter";
import { staggerContainer, fadeUp } from "@/lib/motion";
import { heroStats } from "@/data/site";
import { cssVars } from "@/lib/utils";
import { useInViewOnce } from "@/lib/useInViewOnce";

const line1 = ["Turn", "Ideas"];
const line2 = ["Into", "Impact"];

export function Hero() {
  const shouldReduceMotion = useReducedMotion();
  const { ref: visualRef, inView: visualInView } = useInViewOnce<HTMLDivElement>();

  return (
    <section
      id="home"
      className="relative overflow-hidden bg-white pb-20 pt-32 sm:pb-28 sm:pt-40"
    >
      {/* Decorative background */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -right-40 -top-40 h-[36rem] w-[36rem] rounded-full bg-brand-red/10 blur-3xl" />
        <div className="absolute -left-32 top-1/2 h-96 w-96 -translate-y-1/2 rounded-full bg-brand-red/5 blur-3xl" />
        <svg
          className="absolute inset-x-0 top-0 h-full w-full opacity-[0.035]"
          aria-hidden="true"
        >
          <pattern id="hero-grid" width="48" height="48" patternUnits="userSpaceOnUse">
            <path d="M48 0H0V48" fill="none" stroke="currentColor" strokeWidth="1" />
          </pattern>
          <rect width="100%" height="100%" fill="url(#hero-grid)" />
        </svg>
      </div>

      <Container className="relative grid grid-cols-1 items-center gap-16 lg:grid-cols-12 lg:gap-8">
        {/* Copy */}
        <motion.div
          initial="hidden"
          animate="show"
          variants={staggerContainer(0.09)}
          className="lg:col-span-6"
        >
          <motion.span
            variants={fadeUp}
            className="mb-6 inline-flex items-center gap-2 rounded-full border border-black/10 bg-brand-gray px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.25em] text-brand-dark/70"
          >
            <Sparkles className="h-3.5 w-3.5 text-brand-red" />
            Ideas · Creativity · Impact
          </motion.span>

          <h1 className="font-display text-6xl font-extrabold leading-[0.98] tracking-tight text-brand-dark sm:text-7xl lg:text-[5.5rem]">
            <span className="block overflow-hidden">
              <motion.span variants={fadeUp} className="block">
                {line1.join(" ")}
              </motion.span>
            </span>
            <span className="block overflow-hidden">
              <motion.span variants={fadeUp} className="block text-brand-red">
                {line2.join(" ")}
              </motion.span>
            </span>
          </h1>

          <motion.p
            variants={fadeUp}
            className="mt-7 max-w-lg text-xl font-semibold leading-snug text-brand-dark/85 sm:text-2xl"
          >
            A 360° Advertising Agency for a Stronger, Brighter &amp; Bolder
            Tomorrow.
          </motion.p>

          <motion.p variants={fadeUp} className="mt-5 max-w-lg text-base leading-relaxed text-black/55">
            From Print to Digital, Outdoor to On-Ground, We Create Powerful
            Brand Experiences That Get You Noticed.
          </motion.p>

          <motion.div variants={fadeUp} className="mt-10 flex flex-wrap items-center gap-4">
            <MagneticButton
              href="#contact"
              className="group relative inline-flex items-center gap-2 overflow-hidden rounded-full bg-brand-red px-7 py-4 text-sm font-bold text-white shadow-xl shadow-brand-red/25 transition-transform hover:scale-[1.02] active:scale-[0.98]"
            >
              Start a Project
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </MagneticButton>
            <MagneticButton
              href="#work"
              className="group inline-flex items-center gap-2 rounded-full border-2 border-brand-dark/15 px-7 py-4 text-sm font-bold text-brand-dark transition-colors hover:border-brand-dark"
            >
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-brand-dark text-white transition-colors group-hover:bg-brand-red">
                <Play className="h-2.5 w-2.5 translate-x-px" fill="currentColor" />
              </span>
              View Our Work
            </MagneticButton>
          </motion.div>

          {/* Stats */}
          <motion.dl
            variants={fadeUp}
            className="mt-14 grid grid-cols-2 gap-x-6 gap-y-8 border-t border-black/10 pt-8 sm:grid-cols-4"
          >
            {heroStats.map((stat) => (
              <div key={stat.label}>
                <dt className="sr-only">{stat.label}</dt>
                <dd className="font-display text-3xl font-extrabold text-brand-red sm:text-4xl">
                  <AnimatedCounter value={stat.value} suffix={stat.suffix} />
                </dd>
                <dd className="mt-1 text-xs font-medium leading-tight text-black/55 sm:text-sm">
                  {stat.label}
                </dd>
              </div>
            ))}
          </motion.dl>
        </motion.div>

        {/* Visual composition */}
        <div className="lg:col-span-6">
          <motion.div
            ref={visualRef}
            initial="hidden"
            animate={visualInView ? "show" : "hidden"}
            variants={fadeUp}
            className="relative mx-auto aspect-[5/6] w-full max-w-[440px] sm:aspect-[6/7] lg:max-w-none"
          >
            <div
              className="absolute -right-6 -top-6 h-56 w-56 rounded-full bg-brand-red/20 blur-3xl sm:h-72 sm:w-72"
              aria-hidden="true"
            />

            {/* Main image */}
            <motion.div
              style={cssVars({ "--float-rotate": "-1.5deg" })}
              className="animate-float absolute left-0 top-6 z-20 w-[64%] overflow-hidden rounded-[1.75rem] border-4 border-white shadow-2xl shadow-black/20"
            >
              <Image
                src="/images/work/led-van.jpg"
                alt="Maa Ad Agency hydraulic LED van on-ground campaign"
                width={700}
                height={780}
                priority
                className="aspect-[4/5] w-full object-cover"
              />
            </motion.div>

            {/* Secondary image */}
            <motion.div
              style={cssVars({ "--float-rotate": "2deg" })}
              className="animate-float-slow absolute right-0 top-0 z-30 w-[42%] overflow-hidden rounded-[1.5rem] border-4 border-white shadow-2xl shadow-black/20"
            >
              <Image
                src="/images/work/led-screen-entrance.jpg"
                alt="LED screen advertising display at a Raipur mall"
                width={420}
                height={420}
                className="aspect-square w-full object-cover"
              />
            </motion.div>

            {/* Tertiary image */}
            <motion.div
              style={cssVars({ "--float-rotate": "-2deg" })}
              className="animate-float absolute bottom-4 right-4 z-10 w-[46%] overflow-hidden rounded-[1.5rem] border-4 border-white shadow-2xl shadow-black/20"
            >
              <Image
                src="/images/work/promo-van-paint.jpg"
                alt="Branded promotional van advertising on the street"
                width={480}
                height={380}
                className="aspect-[4/3] w-full object-cover"
              />
            </motion.div>

            {/* Floating badge */}
            <motion.div
              animate={shouldReduceMotion ? undefined : { y: [0, -10, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
              className="absolute bottom-0 left-2 z-40 flex items-center gap-2.5 rounded-2xl border border-black/5 bg-white/95 px-4 py-3 shadow-xl shadow-black/10 backdrop-blur"
            >
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-brand-red/10 text-brand-red">
                <TrendingUp className="h-4 w-4" />
              </span>
              <span className="leading-tight">
                <span className="block text-sm font-extrabold text-brand-dark">
                  Big Brands.
                </span>
                <span className="block text-xs font-medium text-black/50">
                  Bigger Reach.
                </span>
              </span>
            </motion.div>

            {/* Decorative dashed ring */}
            <svg
              className="pointer-events-none absolute -left-8 top-1/3 hidden h-24 w-24 text-brand-red/30 sm:block"
              viewBox="0 0 100 100"
              fill="none"
              aria-hidden="true"
            >
              <circle
                cx="50"
                cy="50"
                r="46"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeDasharray="6 8"
              />
            </svg>
          </motion.div>
        </div>
      </Container>
    </section>
  );
}
