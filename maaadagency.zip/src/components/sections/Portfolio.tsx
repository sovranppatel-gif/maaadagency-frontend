"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { PortfolioCard } from "./PortfolioCard";
import { portfolio, portfolioFilters, type PortfolioCategory } from "@/data/portfolio";
import { cn } from "@/lib/utils";

export function Portfolio() {
  const [filter, setFilter] = useState<"All" | PortfolioCategory>("All");

  const filtered = useMemo(() => {
    if (filter === "All") return portfolio;
    return portfolio.filter((item) => item.categories.includes(filter));
  }, [filter]);

  return (
    <section id="work" className="bg-brand-dark py-24 sm:py-32">
      <Container>
        <div className="flex flex-col items-start justify-between gap-8 lg:flex-row lg:items-end">
          <SectionHeading
            eyebrow="Portfolio"
            title="Our Recent Work"
            tone="light"
            subtitle="A look at campaigns we've planned, produced and delivered on the ground."
          />

          <div className="flex flex-wrap gap-2">
            {portfolioFilters.map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => setFilter(f)}
                className={cn(
                  "relative rounded-full px-4 py-2 text-xs font-bold uppercase tracking-wide transition-colors",
                  filter === f ? "text-white" : "text-white/50 hover:text-white/80"
                )}
              >
                {filter === f && (
                  <motion.span
                    layoutId="portfolio-filter-pill"
                    className="absolute inset-0 rounded-full bg-brand-red"
                    transition={{ type: "spring", stiffness: 400, damping: 32 }}
                  />
                )}
                <span className="relative">{f}</span>
              </button>
            ))}
          </div>
        </div>

        <motion.div
          layout
          className="mt-14 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3"
        >
          <AnimatePresence mode="popLayout">
            {filtered.map((item) => (
              <PortfolioCard key={item.image} item={item} />
            ))}
          </AnimatePresence>
        </motion.div>
      </Container>
    </section>
  );
}
