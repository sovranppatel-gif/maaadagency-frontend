"use client";

import Image from "next/image";
import { motion } from "motion/react";
import { Calendar, Lightbulb, Workflow, TrendingUp } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { Reveal } from "@/components/ui/Reveal";
import { fadeUp, scaleIn, staggerContainer } from "@/lib/motion";
import { cssVars } from "@/lib/utils";
import { useInViewOnce } from "@/lib/useInViewOnce";

const cards = [
  {
    icon: Lightbulb,
    title: "Creative Strategy",
    description: "Ideas rooted in insight, not guesswork.",
  },
  {
    icon: Workflow,
    title: "Execution",
    description: "Seamless delivery across every channel.",
  },
  {
    icon: TrendingUp,
    title: "Brand Growth",
    description: "Campaigns that compound results over time.",
  },
];

export function About() {
  const { ref: visualRef, inView: visualInView } = useInViewOnce<HTMLDivElement>();

  return (
    <section id="about" className="relative overflow-hidden bg-white py-24 sm:py-32">
      <Container className="grid grid-cols-1 items-center gap-16 lg:grid-cols-2 lg:gap-12">
        {/* Copy */}
        <div>
          <Reveal>
            <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-black/10 bg-brand-gray px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-brand-red">
              <span className="h-1.5 w-1.5 rounded-full bg-brand-red" />
              About Us
            </span>
          </Reveal>

          <Reveal delay={0.08}>
            <h2 className="font-display text-4xl font-extrabold leading-[1.05] tracking-tight text-brand-dark sm:text-5xl lg:text-[3.25rem]">
              More Than Advertising.
              <br />
              We Build <span className="text-brand-red">Brand Impact.</span>
            </h2>
          </Reveal>

          <Reveal delay={0.16}>
            <p className="mt-7 text-lg leading-relaxed text-black/60">
              Maa Ad Agency is an advertising and branding company
              established in 2010, providing promotion, printing, outdoor
              advertising, digital marketing and creative branding solutions.
            </p>
          </Reveal>

          <Reveal delay={0.22}>
            <p className="mt-5 text-lg font-semibold leading-relaxed text-brand-dark/80">
              We transform your craziest ideas into powerful creative
              experiences that work for your brand.
            </p>
          </Reveal>

          <Reveal delay={0.3}>
            <a
              href="#services"
              className="mt-9 inline-flex items-center gap-2 border-b-2 border-brand-red pb-1 text-sm font-bold uppercase tracking-wide text-brand-dark transition-colors hover:text-brand-red"
            >
              Explore Our Services
            </a>
          </Reveal>
        </div>

        {/* Visual composition */}
        <motion.div
          ref={visualRef}
          initial="hidden"
          animate={visualInView ? "show" : "hidden"}
          variants={staggerContainer(0.12)}
          className="relative"
        >
          <motion.div
            variants={scaleIn}
            className="relative overflow-hidden rounded-[2rem] bg-brand-dark p-8 text-white sm:p-10"
          >
            <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-brand-red/25 blur-3xl" />
            <Calendar className="h-8 w-8 text-brand-red" />
            <p className="mt-6 font-display text-6xl font-extrabold sm:text-7xl">
              15<span className="text-brand-red">+</span>
            </p>
            <p className="mt-2 text-sm font-medium uppercase tracking-[0.15em] text-white/60">
              Years of Experience — Delivering Excellence Since 2010
            </p>

            <motion.div
              style={cssVars({ "--float-rotate": "3deg" })}
              className="animate-float absolute -right-6 -top-8 hidden w-32 overflow-hidden rounded-2xl border-4 border-white shadow-2xl sm:block"
            >
              <Image
                src="/images/work/offset-press.jpg"
                alt="Offset printing production at Maa Ad Agency"
                width={200}
                height={160}
                className="aspect-[4/3] w-full object-cover"
              />
            </motion.div>
          </motion.div>

          <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-3">
            {cards.map((card) => (
              <motion.div
                key={card.title}
                variants={fadeUp}
                className="group rounded-2xl border border-black/8 bg-brand-gray p-5 transition-colors hover:bg-white hover:shadow-xl hover:shadow-black/5"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-red/10 text-brand-red transition-colors group-hover:bg-brand-red group-hover:text-white">
                  <card.icon className="h-5 w-5" />
                </span>
                <p className="mt-4 font-display text-base font-bold text-brand-dark">
                  {card.title}
                </p>
                <p className="mt-1 text-sm leading-snug text-black/55">
                  {card.description}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </Container>
    </section>
  );
}
