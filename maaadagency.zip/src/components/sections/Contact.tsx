"use client";

import { useState, type FormEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Phone, Mail, MapPin, Building2, CheckCircle2, Send } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { Reveal } from "@/components/ui/Reveal";
import { site } from "@/data/site";
import { services } from "@/data/services";
import { telHref, cn } from "@/lib/utils";

type FormState = {
  name: string;
  company: string;
  phone: string;
  email: string;
  service: string;
  message: string;
};

const initialState: FormState = {
  name: "",
  company: "",
  phone: "",
  email: "",
  service: "",
  message: "",
};

const PHONE_RE = /^[6-9]\d{9}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function Contact() {
  const [form, setForm] = useState<FormState>(initialState);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: undefined }));
  }

  function validate(): boolean {
    const next: Partial<Record<keyof FormState, string>> = {};
    if (!form.name.trim() || form.name.trim().length < 2) {
      next.name = "Please enter your full name.";
    }
    if (!PHONE_RE.test(form.phone.replace(/\s+/g, ""))) {
      next.phone = "Enter a valid 10-digit mobile number.";
    }
    if (!EMAIL_RE.test(form.email.trim())) {
      next.email = "Enter a valid email address.";
    }
    if (!form.service) {
      next.service = "Please select a service.";
    }
    if (!form.message.trim() || form.message.trim().length < 10) {
      next.message = "Tell us a little more about your project (min. 10 characters).";
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!validate()) return;

    setSubmitting(true);
    window.setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
    }, 900);
  }

  function reset() {
    setForm(initialState);
    setErrors({});
    setSubmitted(false);
  }

  const inputClass =
    "w-full rounded-xl border bg-white px-4 py-3 text-sm text-brand-dark placeholder:text-black/35 outline-none transition-colors focus:border-brand-red focus:ring-2 focus:ring-brand-red/20";

  return (
    <section id="contact" className="bg-brand-gray py-24 sm:py-32">
      <Container className="grid grid-cols-1 gap-14 lg:grid-cols-2 lg:gap-10">
        {/* Info */}
        <div>
          <Reveal>
            <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-black/10 bg-white px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-brand-red">
              Get In Touch
            </span>
          </Reveal>
          <Reveal delay={0.08}>
            <h2 className="font-display text-4xl font-extrabold leading-[1.05] tracking-tight text-brand-dark sm:text-5xl">
              Have an Idea?
              <br />
              Let&apos;s Make It Happen.
            </h2>
          </Reveal>
          <Reveal delay={0.16}>
            <p className="mt-6 max-w-md text-lg leading-relaxed text-black/60">
              Tell us about your brand and your goals — our team will get
              back to you to plan the right campaign for you.
            </p>
          </Reveal>

          <Reveal delay={0.24}>
            <div className="mt-10 space-y-5">
              <div className="flex items-start gap-4 rounded-2xl border border-black/8 bg-white p-5">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-red/10 text-brand-red">
                  <Phone className="h-5 w-5" />
                </span>
                <div>
                  <p className="text-xs font-bold uppercase tracking-wide text-black/40">Phone</p>
                  <div className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5">
                    {site.phones.map((phone) => (
                      <a
                        key={phone}
                        href={telHref(phone)}
                        className="text-sm font-semibold text-brand-dark hover:text-brand-red"
                      >
                        +91 {phone}
                      </a>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-4 rounded-2xl border border-black/8 bg-white p-5">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-red/10 text-brand-red">
                  <Mail className="h-5 w-5" />
                </span>
                <div>
                  <p className="text-xs font-bold uppercase tracking-wide text-black/40">Email &amp; Website</p>
                  <a
                    href={`mailto:${site.email}`}
                    className="mt-1 block text-sm font-semibold text-brand-dark hover:text-brand-red"
                  >
                    {site.email}
                  </a>
                  <a
                    href={site.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block text-sm font-semibold text-brand-dark hover:text-brand-red"
                  >
                    {site.website}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4 rounded-2xl border border-black/8 bg-white p-5">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-red/10 text-brand-red">
                  <MapPin className="h-5 w-5" />
                </span>
                <div>
                  <p className="text-xs font-bold uppercase tracking-wide text-black/40">Address</p>
                  <p className="mt-1 text-sm font-semibold text-brand-dark">
                    {site.address.line1}
                    <br />
                    {site.address.line2}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 rounded-2xl border border-black/8 bg-white p-5">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-red/10 text-brand-red">
                  <Building2 className="h-5 w-5" />
                </span>
                <div>
                  <p className="text-xs font-bold uppercase tracking-wide text-black/40">
                    Registration Office
                  </p>
                  <p className="mt-1 text-sm font-semibold text-brand-dark">
                    {site.registrationOffice.line1}
                    <br />
                    {site.registrationOffice.line2}
                  </p>
                </div>
              </div>
            </div>
          </Reveal>
        </div>

        {/* Form */}
        <Reveal delay={0.1}>
          <div className="relative overflow-hidden rounded-[2rem] bg-white p-6 shadow-xl shadow-black/5 sm:p-9">
            <AnimatePresence mode="wait">
              {submitted ? (
                <motion.div
                  key="success"
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -12 }}
                  transition={{ duration: 0.4 }}
                  className="flex min-h-[26rem] flex-col items-center justify-center text-center"
                >
                  <motion.span
                    initial={{ scale: 0.6, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ type: "spring", stiffness: 260, damping: 18, delay: 0.1 }}
                    className="flex h-16 w-16 items-center justify-center rounded-full bg-brand-red/10 text-brand-red"
                  >
                    <CheckCircle2 className="h-8 w-8" />
                  </motion.span>
                  <h3 className="mt-6 font-display text-2xl font-extrabold text-brand-dark">
                    Enquiry Sent!
                  </h3>
                  <p className="mt-2 max-w-xs text-sm leading-relaxed text-black/55">
                    Thank you for reaching out. Our team will get back to you
                    shortly to discuss your project.
                  </p>
                  <button
                    type="button"
                    onClick={reset}
                    className="mt-7 inline-flex items-center gap-2 rounded-full border-2 border-brand-dark/15 px-6 py-3 text-sm font-bold text-brand-dark transition-colors hover:border-brand-red hover:text-brand-red"
                  >
                    Send Another Enquiry
                  </button>
                </motion.div>
              ) : (
                <motion.form
                  key="form"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  onSubmit={handleSubmit}
                  noValidate
                  className="space-y-5"
                >
                  <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div>
                      <label htmlFor="name" className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-black/50">
                        Name
                      </label>
                      <input
                        id="name"
                        type="text"
                        value={form.name}
                        onChange={(e) => update("name", e.target.value)}
                        placeholder="Your full name"
                        aria-invalid={Boolean(errors.name)}
                        className={cn(inputClass, errors.name ? "border-brand-red" : "border-black/10")}
                      />
                      {errors.name && <p className="mt-1.5 text-xs text-brand-red">{errors.name}</p>}
                    </div>

                    <div>
                      <label htmlFor="company" className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-black/50">
                        Company
                      </label>
                      <input
                        id="company"
                        type="text"
                        value={form.company}
                        onChange={(e) => update("company", e.target.value)}
                        placeholder="Your company (optional)"
                        className={cn(inputClass, "border-black/10")}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div>
                      <label htmlFor="phone" className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-black/50">
                        Phone
                      </label>
                      <input
                        id="phone"
                        type="tel"
                        inputMode="numeric"
                        value={form.phone}
                        onChange={(e) => update("phone", e.target.value)}
                        placeholder="98765 43210"
                        aria-invalid={Boolean(errors.phone)}
                        className={cn(inputClass, errors.phone ? "border-brand-red" : "border-black/10")}
                      />
                      {errors.phone && <p className="mt-1.5 text-xs text-brand-red">{errors.phone}</p>}
                    </div>

                    <div>
                      <label htmlFor="email" className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-black/50">
                        Email
                      </label>
                      <input
                        id="email"
                        type="email"
                        value={form.email}
                        onChange={(e) => update("email", e.target.value)}
                        placeholder="you@email.com"
                        aria-invalid={Boolean(errors.email)}
                        className={cn(inputClass, errors.email ? "border-brand-red" : "border-black/10")}
                      />
                      {errors.email && <p className="mt-1.5 text-xs text-brand-red">{errors.email}</p>}
                    </div>
                  </div>

                  <div>
                    <label htmlFor="service" className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-black/50">
                      Service
                    </label>
                    <select
                      id="service"
                      value={form.service}
                      onChange={(e) => update("service", e.target.value)}
                      aria-invalid={Boolean(errors.service)}
                      className={cn(inputClass, "appearance-none", errors.service ? "border-brand-red" : "border-black/10")}
                    >
                      <option value="">Select a service</option>
                      {services.map((s) => (
                        <option key={s.title} value={s.title}>
                          {s.title}
                        </option>
                      ))}
                    </select>
                    {errors.service && <p className="mt-1.5 text-xs text-brand-red">{errors.service}</p>}
                  </div>

                  <div>
                    <label htmlFor="message" className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-black/50">
                      Project Details
                    </label>
                    <textarea
                      id="message"
                      rows={4}
                      value={form.message}
                      onChange={(e) => update("message", e.target.value)}
                      placeholder="Tell us about your brand and what you'd like to achieve..."
                      aria-invalid={Boolean(errors.message)}
                      className={cn(inputClass, "resize-none", errors.message ? "border-brand-red" : "border-black/10")}
                    />
                    {errors.message && <p className="mt-1.5 text-xs text-brand-red">{errors.message}</p>}
                  </div>

                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex w-full items-center justify-center gap-2 rounded-full bg-brand-red px-7 py-4 text-sm font-bold text-white shadow-lg shadow-brand-red/25 transition-transform hover:scale-[1.01] active:scale-[0.98] disabled:opacity-70"
                  >
                    {submitting ? (
                      "Sending..."
                    ) : (
                      <>
                        Send Enquiry
                        <Send className="h-4 w-4" />
                      </>
                    )}
                  </button>
                </motion.form>
              )}
            </AnimatePresence>
          </div>
        </Reveal>
      </Container>
    </section>
  );
}
