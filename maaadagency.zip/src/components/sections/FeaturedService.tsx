"use client";

import Image from "next/image";
import { motion } from "motion/react";
import { Check, Radio, MapPin } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { Reveal } from "@/components/ui/Reveal";
import { fadeUp, staggerContainer } from "@/lib/motion";
import { featuredVan } from "@/data/outdoor";
import { cssVars } from "@/lib/utils";
import { useInViewOnce } from "@/lib/useInViewOnce";

export function FeaturedService() {
  const { ref: imageRef, inView: imageInView } = useInViewOnce<HTMLDivElement>();
  const { ref: featuresRef, inView: featuresInView } = useInViewOnce<HTMLUListElement>();

  return (
    <section className="overflow-hidden bg-white py-24 sm:py-32">
      <Container className="grid grid-cols-1 items-center gap-16 lg:grid-cols-2 lg:gap-14">
        {/* Image */}
        <div
          ref={imageRef}
          className={`relative order-2 transition-[clip-path,opacity] duration-[900ms] ease-[cubic-bezier(0.16,1,0.3,1)] lg:order-1 ${
            imageInView ? "opacity-100 [clip-path:inset(0_0_0%_0)]" : "opacity-0 [clip-path:inset(0_0_100%_0)]"
          }`}
        >
          <div className="relative overflow-hidden rounded-[2rem] shadow-2xl shadow-black/20">
            <Image
              src={featuredVan.image}
              alt="Maa Ad Agency hydraulic LED van mobile advertising"
              width={800}
              height={720}
              className="aspect-[4/5] w-full object-cover sm:aspect-[5/5.5]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
          </div>

          <motion.div
            style={cssVars({ "--float-rotate": "-2deg" })}
            className="animate-float absolute -left-4 top-8 flex items-center gap-3 rounded-2xl border border-black/5 bg-white px-4 py-3 shadow-xl shadow-black/10 sm:-left-8"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-brand-red/10 text-brand-red">
              <Radio className="h-4 w-4" />
            </span>
            <span className="leading-tight">
              <span className="block text-sm font-extrabold text-brand-dark">
                Live LED + Audio
              </span>
              <span className="block text-xs text-black/50">Moving Screen</span>
            </span>
          </motion.div>

          <motion.div
            style={cssVars({ "--float-rotate": "2deg" })}
            className="animate-float-slow absolute -bottom-6 -right-2 flex items-center gap-3 rounded-2xl border border-black/5 bg-white px-4 py-3 shadow-xl shadow-black/10 sm:-right-8"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-brand-red/10 text-brand-red">
              <MapPin className="h-4 w-4" />
            </span>
            <span className="leading-tight">
              <span className="block text-sm font-extrabold text-brand-dark">
                Local &amp; Regional
              </span>
              <span className="block text-xs text-black/50">Campaign Reach</span>
            </span>
          </motion.div>
        </div>

        {/* Content */}
        <div className="order-1 lg:order-2">
          <Reveal>
            <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-black/10 bg-brand-gray px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-brand-red">
              Featured Service
            </span>
          </Reveal>
          <Reveal delay={0.08}>
            <h2 className="font-display text-4xl font-extrabold leading-[1.05] tracking-tight text-brand-dark sm:text-5xl">
              {featuredVan.title}
            </h2>
          </Reveal>
          <Reveal delay={0.16}>
            <p className="mt-6 max-w-md text-lg leading-relaxed text-black/60">
              {featuredVan.description}
            </p>
          </Reveal>

          <motion.ul
            ref={featuresRef}
            initial="hidden"
            animate={featuresInView ? "show" : "hidden"}
            variants={staggerContainer(0.08, 0.2)}
            className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-2"
          >
            {featuredVan.features.map((feature) => (
              <motion.li
                key={feature}
                variants={fadeUp}
                className="flex items-center gap-3 rounded-xl bg-brand-gray px-4 py-3 text-sm font-semibold text-brand-dark"
              >
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-brand-red text-white">
                  <Check className="h-3.5 w-3.5" strokeWidth={3} />
                </span>
                {feature}
              </motion.li>
            ))}
          </motion.ul>

          <Reveal delay={0.3}>
            <a
              href="#contact"
              className="mt-9 inline-flex items-center gap-2 rounded-full bg-brand-dark px-7 py-4 text-sm font-bold text-white transition-colors hover:bg-brand-red"
            >
              Book Your LED Van Campaign
            </a>
          </Reveal>
        </div>
      </Container>
    </section>
  );
}
