import Image from "next/image";
import { Container } from "@/components/ui/Container";
import { Reveal } from "@/components/ui/Reveal";
import { clients } from "@/data/clients";

export function TrustedBrands() {
  const loop = [...clients, ...clients];

  return (
    <section id="clients" className="border-y border-black/5 bg-white py-14 sm:py-16">
      <Container>
        <Reveal className="mb-10 flex flex-col items-center justify-between gap-3 sm:flex-row">
          <p className="text-xs font-bold uppercase tracking-[0.25em] text-black/45">
            Trusted by Leading Brands
          </p>
          <a
            href="#work"
            className="text-xs font-bold uppercase tracking-[0.2em] text-brand-red transition-opacity hover:opacity-70"
          >
            View All →
          </a>
        </Reveal>
      </Container>

      <div className="marquee-row relative overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_8%,black_92%,transparent)]">
        <div className="marquee-track flex w-max animate-marquee items-center gap-14 sm:gap-20">
          {loop.map((client, i) => (
            <div
              key={`${client.name}-${i}`}
              className="flex h-14 w-32 shrink-0 items-center justify-center grayscale transition-all duration-300 hover:scale-105 hover:grayscale-0 sm:h-16 sm:w-36"
            >
              <Image
                src={client.logo}
                alt={client.name}
                width={160}
                height={70}
                className="h-full w-full object-contain"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
