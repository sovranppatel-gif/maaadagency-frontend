"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { AnimatePresence, motion } from "motion/react";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { testimonials } from "@/data/testimonials";
import { cn } from "@/lib/utils";

const AUTOPLAY_MS = 6000;

export function Testimonials() {
  const [index, setIndex] = useState(0);
  const [direction, setDirection] = useState(1);
  const [paused, setPaused] = useState(false);

  const go = useCallback(
    (next: number) => {
      setDirection(next > index || (index === testimonials.length - 1 && next === 0) ? 1 : -1);
      setIndex((next + testimonials.length) % testimonials.length);
    },
    [index]
  );

  useEffect(() => {
    if (paused) return;
    const timer = setInterval(() => {
      setDirection(1);
      setIndex((i) => (i + 1) % testimonials.length);
    }, AUTOPLAY_MS);
    return () => clearInterval(timer);
  }, [paused]);

  const current = testimonials[index];

  return (
    <section className="bg-white py-24 sm:py-32">
      <Container>
        <SectionHeading
          eyebrow="Testimonials"
          title="What Our Clients Say"
          align="center"
          subtitle="Real feedback from the brands we've worked alongside."
        />

        <div
          className="relative mx-auto mt-14 max-w-3xl"
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
        >
          <div className="relative overflow-hidden rounded-[2rem] bg-brand-gray px-6 py-12 sm:px-14 sm:py-16">
            <Quote className="mx-auto h-10 w-10 text-brand-red/25" />

            <div className="relative mt-6 min-h-[13rem] sm:min-h-[10rem]">
              <AnimatePresence mode="wait" custom={direction}>
                <motion.div
                  key={index}
                  custom={direction}
                  initial={{ opacity: 0, x: direction * 40 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: direction * -40 }}
                  transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                  className="absolute inset-0 flex flex-col items-center text-center"
                >
                  <p className="text-balance font-display text-xl font-semibold leading-relaxed text-brand-dark sm:text-2xl">
                    &ldquo;{current.quote}&rdquo;
                  </p>

                  <div className="mt-7 flex items-center gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-white p-1.5 shadow-sm">
                      <Image
                        src={current.logo}
                        alt={current.company}
                        width={40}
                        height={40}
                        className="h-full w-full object-contain"
                      />
                    </div>
                    <div className="text-left">
                      <p className="text-sm font-bold text-brand-dark">{current.name}</p>
                      <p className="text-xs text-black/50">
                        {current.role}, {current.company}
                      </p>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>

          <button
            type="button"
            onClick={() => go(index - 1)}
            aria-label="Previous testimonial"
            className="absolute left-0 top-1/2 hidden -translate-x-5 -translate-y-1/2 items-center justify-center rounded-full border border-black/10 bg-white p-3 shadow-lg transition-colors hover:border-brand-red hover:text-brand-red sm:flex"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button
            type="button"
            onClick={() => go(index + 1)}
            aria-label="Next testimonial"
            className="absolute right-0 top-1/2 hidden -translate-y-1/2 translate-x-5 items-center justify-center rounded-full border border-black/10 bg-white p-3 shadow-lg transition-colors hover:border-brand-red hover:text-brand-red sm:flex"
          >
            <ChevronRight className="h-5 w-5" />
          </button>

          <div className="mt-8 flex items-center justify-center gap-2">
            {testimonials.map((t, i) => (
              <button
                key={t.name}
                type="button"
                onClick={() => go(i)}
                aria-label={`Go to testimonial ${i + 1}`}
                className={cn(
                  "h-2 rounded-full transition-all duration-300",
                  i === index ? "w-7 bg-brand-red" : "w-2 bg-black/15 hover:bg-black/30"
                )}
              />
            ))}
          </div>

          <div className="mt-6 flex items-center justify-center gap-2 sm:hidden">
            <button
              type="button"
              onClick={() => go(index - 1)}
              aria-label="Previous testimonial"
              className="flex items-center justify-center rounded-full border border-black/10 bg-white p-3"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => go(index + 1)}
              aria-label="Next testimonial"
              className="flex items-center justify-center rounded-full border border-black/10 bg-white p-3"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </div>
      </Container>
    </section>
  );
}
