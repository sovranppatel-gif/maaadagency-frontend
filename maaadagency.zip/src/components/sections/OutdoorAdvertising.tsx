"use client";

import { useRef } from "react";
import Image from "next/image";
import { motion, useScroll, useTransform, useReducedMotion } from "motion/react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { outdoorGallery } from "@/data/outdoor";

const heights = ["sm:h-[26rem]", "sm:h-[20rem]", "sm:h-[30rem]", "sm:h-[22rem]", "sm:h-[26rem]"];
const offsets = [30, -30, 40, -40, 30];

function ParallaxTile({
  image,
  title,
  tag,
  heightClass,
  yOffset,
  index,
}: {
  image: string;
  title: string;
  tag: string;
  heightClass: string;
  yOffset: number;
  index: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const shouldReduceMotion = useReducedMotion();
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const y = useTransform(scrollYProgress, [0, 1], [yOffset, -yOffset]);

  return (
    <div
      ref={ref}
      className={`relative h-72 ${heightClass} ${index % 2 === 1 ? "lg:mt-10" : ""}`}
    >
      <motion.div
        style={shouldReduceMotion ? undefined : { y }}
        className="group relative h-full overflow-hidden rounded-3xl shadow-lg shadow-black/10"
      >
        <Image
          src={image}
          alt={title}
          fill
          sizes="(min-width: 1024px) 20vw, (min-width: 640px) 45vw, 90vw"
          className="object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent opacity-90" />
        <div className="absolute inset-x-0 bottom-0 p-5">
          <p className="font-display text-lg font-bold text-white">{title}</p>
          <p className="mt-0.5 text-xs font-medium text-white/70">{tag}</p>
        </div>
      </motion.div>
    </div>
  );
}

export function OutdoorAdvertising() {
  return (
    <section className="overflow-hidden bg-white py-24 sm:py-32">
      <Container>
        <SectionHeading
          eyebrow="Outdoor Advertising"
          title="Your Brand. Everywhere."
          subtitle="From promotional vans to digital wall painting and LED screens — we put your brand in front of real audiences, on real streets."
        />

        <div className="mt-16 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-5 lg:items-start">
          {outdoorGallery.map((item, i) => (
            <ParallaxTile
              key={item.image}
              image={item.image}
              title={item.title}
              tag={item.tag}
              heightClass={heights[i % heights.length]}
              yOffset={offsets[i % offsets.length]}
              index={i}
            />
          ))}
        </div>
      </Container>
    </section>
  );
}
