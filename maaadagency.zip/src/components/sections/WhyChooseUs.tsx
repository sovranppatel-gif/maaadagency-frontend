"use client";

import { motion } from "motion/react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { AnimatedCounter } from "@/components/ui/AnimatedCounter";
import { fadeUp, staggerContainer } from "@/lib/motion";
import { useInViewOnce } from "@/lib/useInViewOnce";
import { whyChooseUsStats, whyPoints } from "@/data/whyChooseUs";

export function WhyChooseUs() {
  const { ref: statsRef, inView: statsInView } = useInViewOnce<HTMLDivElement>();
  const { ref: pointsRef, inView: pointsInView } = useInViewOnce<HTMLDivElement>();

  return (
    <section className="bg-brand-gray py-24 sm:py-32">
      <Container>
        <SectionHeading
          eyebrow="Why Us"
          title="Why Brands Choose Maa Ad Agency"
          align="center"
          subtitle="Fifteen years of on-ground experience, backed by creative thinking and end-to-end execution."
        />

        {/* Stats strip */}
        <motion.div
          ref={statsRef}
          initial="hidden"
          animate={statsInView ? "show" : "hidden"}
          variants={staggerContainer(0.1)}
          className="mt-14 grid grid-cols-2 gap-4 rounded-[2rem] bg-brand-dark p-8 sm:grid-cols-4 sm:p-10"
        >
          {whyChooseUsStats.map((stat) => (
            <motion.div key={stat.label} variants={fadeUp} className="text-center sm:text-left">
              <p className="font-display text-4xl font-extrabold text-white sm:text-5xl">
                <AnimatedCounter value={stat.value} suffix={stat.suffix} className="text-brand-red" />
              </p>
              <p className="mt-2 text-xs font-medium leading-tight text-white/55 sm:text-sm">
                {stat.label}
              </p>
            </motion.div>
          ))}
        </motion.div>

        {/* Points grid */}
        <motion.div
          ref={pointsRef}
          initial="hidden"
          animate={pointsInView ? "show" : "hidden"}
          variants={staggerContainer(0.08)}
          className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3"
        >
          {whyPoints.map((point) => (
            <motion.div
              key={point.title}
              variants={fadeUp}
              whileHover={{ y: -4 }}
              className="rounded-2xl border border-black/8 bg-white p-6 shadow-sm transition-shadow duration-300 hover:shadow-xl hover:shadow-black/5"
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-red/10 text-brand-red">
                <point.icon className="h-5 w-5" />
              </span>
              <p className="mt-4 font-display text-base font-bold text-brand-dark">
                {point.title}
              </p>
              <p className="mt-1.5 text-sm leading-relaxed text-black/55">
                {point.description}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </Container>
    </section>
  );
}
