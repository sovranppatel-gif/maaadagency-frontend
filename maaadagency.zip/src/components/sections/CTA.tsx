"use client";

import { motion, useReducedMotion } from "motion/react";
import { ArrowRight, Phone } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { Reveal } from "@/components/ui/Reveal";
import { MagneticButton } from "@/components/ui/MagneticButton";
import { site } from "@/data/site";
import { telHref } from "@/lib/utils";

export function CTA() {
  const shouldReduceMotion = useReducedMotion();

  return (
    <section className="relative overflow-hidden bg-brand-red py-24 sm:py-28">
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        <motion.div
          animate={shouldReduceMotion ? undefined : { x: [0, 30, 0], y: [0, -20, 0] }}
          transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
          className="absolute -left-24 -top-24 h-96 w-96 rounded-full bg-white/10 blur-3xl"
        />
        <motion.div
          animate={shouldReduceMotion ? undefined : { x: [0, -30, 0], y: [0, 25, 0] }}
          transition={{ duration: 14, repeat: Infinity, ease: "easeInOut" }}
          className="absolute -bottom-32 -right-16 h-[28rem] w-[28rem] rounded-full bg-black/15 blur-3xl"
        />
        <svg className="absolute inset-0 h-full w-full opacity-[0.08]" aria-hidden="true">
          <pattern id="cta-dots" width="28" height="28" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1.5" fill="white" />
          </pattern>
          <rect width="100%" height="100%" fill="url(#cta-dots)" />
        </svg>
      </div>

      <Container className="relative text-center">
        <Reveal>
          <h2 className="mx-auto max-w-2xl text-balance font-display text-4xl font-extrabold leading-[1.05] tracking-tight text-white sm:text-5xl lg:text-6xl">
            Let&apos;s Build Your Brand Together
          </h2>
        </Reveal>
        <Reveal delay={0.1}>
          <p className="mx-auto mt-6 max-w-lg text-lg leading-relaxed text-white/85">
            From a small idea to a big campaign — we&apos;re here to make it
            happen.
          </p>
        </Reveal>

        <Reveal delay={0.2}>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
            <MagneticButton
              href="#contact"
              className="group inline-flex items-center gap-2 rounded-full bg-white px-7 py-4 text-sm font-bold text-brand-red shadow-xl shadow-black/10 transition-transform hover:scale-[1.02] active:scale-[0.98]"
            >
              Start a Project
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </MagneticButton>
            <MagneticButton
              href={telHref(site.phones[0])}
              className="inline-flex items-center gap-2 rounded-full border-2 border-white/40 px-7 py-4 text-sm font-bold text-white transition-colors hover:border-white"
            >
              <Phone className="h-4 w-4" />
              Talk to Our Team
            </MagneticButton>
          </div>
        </Reveal>
      </Container>
    </section>
  );
}
