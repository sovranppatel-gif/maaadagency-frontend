"use client";

import Image from "next/image";
import { motion } from "motion/react";
import { Printer, Megaphone, ArrowRight, type LucideIcon } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/ui/Reveal";
import { fadeUp, scaleIn, staggerContainer } from "@/lib/motion";
import { useInViewOnce } from "@/lib/useInViewOnce";
import { printServices, digitalServices } from "@/data/printDigital";

type Panel = {
  key: string;
  icon: LucideIcon;
  title: string;
  description: string;
  items: string[];
  image: string;
  dark: boolean;
};

const panels: Panel[] = [
  {
    key: "print",
    icon: Printer,
    title: "Print",
    description: "Premium print production for every business need.",
    items: printServices,
    image: "/images/work/flex-printer.jpg",
    dark: false,
  },
  {
    key: "digital",
    icon: Megaphone,
    title: "Digital",
    description: "Data-driven digital marketing that builds real reach.",
    items: digitalServices,
    image: "/images/work/flex-printer-operator.jpg",
    dark: true,
  },
];

function PanelCard({ panel }: { panel: Panel }) {
  const { ref, inView } = useInViewOnce<HTMLUListElement>();

  return (
    <Reveal variants={scaleIn}>
      <div
        className={`relative overflow-hidden rounded-[2rem] p-8 sm:p-10 ${
          panel.dark ? "bg-brand-dark text-white" : "bg-brand-gray text-brand-dark"
        }`}
      >
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <span
              className={`flex h-14 w-14 items-center justify-center rounded-2xl ${
                panel.dark ? "bg-white/10 text-brand-red" : "bg-white text-brand-red"
              }`}
            >
              <panel.icon className="h-6 w-6" />
            </span>
            <div className="relative hidden h-20 w-28 overflow-hidden rounded-xl sm:block">
              <Image
                src={panel.image}
                alt={`${panel.title} production at Maa Ad Agency`}
                fill
                sizes="140px"
                className="object-cover"
              />
            </div>
          </div>

          <h3 className="mt-6 font-display text-3xl font-extrabold">{panel.title}</h3>
          <p className={`mt-2 text-sm ${panel.dark ? "text-white/60" : "text-black/55"}`}>
            {panel.description}
          </p>

          <motion.ul
            ref={ref}
            initial="hidden"
            animate={inView ? "show" : "hidden"}
            variants={staggerContainer(0.06)}
            className="mt-7 flex flex-wrap gap-2.5"
          >
            {panel.items.map((item) => (
              <motion.li
                key={item}
                variants={fadeUp}
                whileHover={{ scale: 1.05, y: -2 }}
                className={`rounded-full border px-4 py-2 text-sm font-semibold ${
                  panel.dark
                    ? "border-white/15 bg-white/5 text-white/85"
                    : "border-black/10 bg-white text-brand-dark"
                }`}
              >
                {item}
              </motion.li>
            ))}
          </motion.ul>

          <a
            href="#contact"
            className={`mt-8 inline-flex items-center gap-2 text-sm font-bold uppercase tracking-wide ${
              panel.dark ? "text-white" : "text-brand-dark"
            } group`}
          >
            Get a Quote
            <ArrowRight className="h-4 w-4 text-brand-red transition-transform group-hover:translate-x-1" />
          </a>
        </div>
      </div>
    </Reveal>
  );
}

export function PrintDigital() {
  return (
    <section className="bg-white py-24 sm:py-32">
      <Container>
        <SectionHeading
          eyebrow="Print & Digital"
          title="Traditional Craft. Digital Precision."
          subtitle="Whether it's ink on paper or pixels on screen, we deliver with the same attention to detail."
        />

        <div className="mt-16 grid grid-cols-1 gap-6 lg:grid-cols-2">
          {panels.map((panel) => (
            <PanelCard key={panel.key} panel={panel} />
          ))}
        </div>
      </Container>
    </section>
  );
}
