"use client";

import Image from "next/image";
import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { scaleIn } from "@/lib/motion";
import { useInViewOnce } from "@/lib/useInViewOnce";

type ShowcaseProject = {
  image: string;
  title: string;
  tag: string;
  size: string;
  aspect: string;
};

const showcase: ShowcaseProject[] = [
  {
    image: "/images/work/led-van.jpg",
    title: "Hydraulic LED Van",
    tag: "Outdoor · LED · BNI Campaign",
    size: "lg:col-span-2 lg:row-span-2",
    aspect: "aspect-[4/5] lg:aspect-auto",
  },
  {
    image: "/images/work/led-screen-entrance.jpg",
    title: "Mall LED Screen",
    tag: "Digital Display",
    size: "lg:col-span-1 lg:row-span-1",
    aspect: "aspect-[4/3]",
  },
  {
    image: "/images/work/promo-van-bike.jpg",
    title: "Promotional Van",
    tag: "Van Branding",
    size: "lg:col-span-1 lg:row-span-1",
    aspect: "aspect-[4/3]",
  },
  {
    image: "/images/work/digital-wall-painting.jpg",
    title: "Digital Wall Painting",
    tag: "Outdoor Branding",
    size: "lg:col-span-2 lg:row-span-1",
    aspect: "aspect-[16/9]",
  },
];

function ShowcaseTile({ project }: { project: ShowcaseProject }) {
  const { ref, inView } = useInViewOnce<HTMLDivElement>();

  return (
    <motion.div
      ref={ref}
      initial="hidden"
      animate={inView ? "show" : "hidden"}
      variants={scaleIn}
      className={`group relative overflow-hidden rounded-3xl ${project.size} ${project.aspect}`}
    >
      <Image
        src={project.image}
        alt={project.title}
        fill
        sizes="(min-width: 1024px) 50vw, 90vw"
        className="object-cover transition-transform duration-700 group-hover:scale-105"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />
      <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.15em] text-white/60">
            {project.tag}
          </p>
          <p className="mt-1 font-display text-2xl font-extrabold text-white">{project.title}</p>
        </div>
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white/15 text-white backdrop-blur transition-all duration-300 group-hover:bg-brand-red">
          <ArrowUpRight className="h-4 w-4" />
        </span>
      </div>
    </motion.div>
  );
}

export function ProjectShowcase() {
  return (
    <section className="bg-white py-24 sm:py-32">
      <Container>
        <SectionHeading
          eyebrow="Showcase"
          title="Work That Speaks for Itself"
          subtitle="A closer look at the campaigns bringing brands to life across Chhattisgarh."
        />

        <div className="mt-14 grid grid-cols-1 gap-5 lg:grid-cols-4 lg:grid-rows-2">
          {showcase.map((project) => (
            <ShowcaseTile key={project.title} project={project} />
          ))}
        </div>
      </Container>
    </section>
  );
}
