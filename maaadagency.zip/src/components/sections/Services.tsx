"use client";

import { motion } from "motion/react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { ServiceCard } from "./ServiceCard";
import { staggerContainer } from "@/lib/motion";
import { useInViewOnce } from "@/lib/useInViewOnce";
import { services } from "@/data/services";

export function Services() {
  const { ref, inView } = useInViewOnce<HTMLDivElement>();

  return (
    <section id="services" className="bg-brand-gray py-24 sm:py-32">
      <Container>
        <SectionHeading
          eyebrow="What We Do"
          title="Our Exclusive Services"
          subtitle="Complete Advertising & Branding Solutions Under One Roof"
          align="center"
        />

        <motion.div
          ref={ref}
          initial="hidden"
          animate={inView ? "show" : "hidden"}
          variants={staggerContainer(0.07)}
          className="mt-14 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4"
        >
          {services.map((service) => (
            <ServiceCard key={service.title} service={service} />
          ))}
        </motion.div>
      </Container>
    </section>
  );
}
