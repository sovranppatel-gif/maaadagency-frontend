"use client";

import Image from "next/image";
import { motion } from "motion/react";
import { ArrowRight, MapPin } from "lucide-react";
import type { PortfolioItem } from "@/data/portfolio";

export function PortfolioCard({ item }: { item: PortfolioItem }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.94 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.94 }}
      transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
      className="group relative aspect-[4/5] overflow-hidden rounded-2xl bg-white/5"
    >
      <Image
        src={item.image}
        alt={item.title}
        fill
        sizes="(min-width: 1024px) 30vw, (min-width: 640px) 45vw, 90vw"
        className="object-cover transition-transform duration-700 ease-out group-hover:scale-110"
      />

      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-black/0 transition-opacity duration-500 group-hover:from-black/95 group-hover:via-black/50" />

      <div className="absolute inset-x-0 bottom-0 translate-y-2 p-5 transition-transform duration-500 group-hover:translate-y-0">
        <span className="inline-block rounded-full bg-brand-red px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-white">
          {item.categories[0]}
        </span>
        <p className="mt-3 font-display text-lg font-bold leading-tight text-white">
          {item.title}
        </p>
        {item.location && (
          <p className="mt-1 flex items-center gap-1.5 text-xs text-white/60">
            <MapPin className="h-3 w-3" />
            {item.location}
          </p>
        )}
        <p className="mt-3 flex items-center gap-1.5 text-sm font-bold text-white opacity-0 transition-opacity duration-500 group-hover:opacity-100">
          View Project
          <ArrowRight className="h-3.5 w-3.5" />
        </p>
      </div>
    </motion.div>
  );
}
