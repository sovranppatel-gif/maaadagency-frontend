"use client";

import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import { fadeUp } from "@/lib/motion";
import type { Service } from "@/data/services";

export function ServiceCard({ service }: { service: Service }) {
  const Icon = service.icon;

  return (
    <motion.div
      variants={fadeUp}
      whileHover={{ y: -6 }}
      transition={{ type: "spring", stiffness: 300, damping: 22 }}
      className="group relative overflow-hidden rounded-2xl border border-black/8 bg-white p-6 shadow-sm shadow-black/[0.02] transition-shadow duration-300 hover:shadow-xl hover:shadow-black/[0.06]"
    >
      <span className="absolute inset-x-0 bottom-0 h-0 bg-brand-red/[0.04] transition-all duration-300 group-hover:h-full" />
      <span className="absolute bottom-0 left-0 h-1 w-0 bg-brand-red transition-all duration-300 group-hover:w-full" />

      <div className="relative flex items-start justify-between">
        <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-gray text-brand-red transition-all duration-300 group-hover:-rotate-6 group-hover:bg-brand-red group-hover:text-white">
          <Icon className="h-5 w-5" />
        </span>
        <ArrowUpRight className="h-5 w-5 -translate-x-1 translate-y-1 text-black/20 opacity-0 transition-all duration-300 group-hover:translate-x-0 group-hover:translate-y-0 group-hover:text-brand-red group-hover:opacity-100" />
      </div>

      <h3 className="relative mt-5 font-display text-lg font-bold text-brand-dark">
        {service.title}
      </h3>
      <p className="relative mt-2 text-sm leading-relaxed text-black/55">
        {service.description}
      </p>
    </motion.div>
  );
}
