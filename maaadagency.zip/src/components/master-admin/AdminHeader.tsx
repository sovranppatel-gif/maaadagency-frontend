"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "motion/react";
import { Bell, Menu, Search, Wifi, WifiOff } from "lucide-react";
import { getPageTitle } from "@/lib/admin-nav";
import { whatsappConfig, currentAdmin } from "@/lib/mock-data/settings";
import { notifications as notificationsStore } from "@/lib/mock-data/notifications";
import { cn } from "@/lib/utils";
import { timeAgo } from "@/lib/format";

export function AdminHeader({ onMenuClick }: { onMenuClick: () => void }) {
  const pathname = usePathname();
  const title = getPageTitle(pathname);
  const [bellOpen, setBellOpen] = useState(false);
  const bellRef = useRef<HTMLDivElement>(null);
  const unread = notificationsStore.filter((n) => !n.read).length;

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (bellRef.current && !bellRef.current.contains(e.target as Node)) setBellOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-black/8 bg-white/90 px-4 backdrop-blur-md sm:px-6">
      <button
        type="button"
        onClick={onMenuClick}
        aria-label="Open sidebar menu"
        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-neutral-500 hover:bg-neutral-100 lg:hidden"
      >
        <Menu className="h-5 w-5" />
      </button>

      <h1 className="shrink-0 text-base font-extrabold text-neutral-900 sm:text-lg">{title}</h1>

      <div className="ml-2 hidden max-w-sm flex-1 items-center gap-2 rounded-lg bg-neutral-100 px-3 py-2 md:flex">
        <Search className="h-4 w-4 shrink-0 text-neutral-400" />
        <input
          type="text"
          placeholder="Search leads, work, clients..."
          className="w-full bg-transparent text-sm text-neutral-700 outline-none placeholder:text-neutral-400"
        />
      </div>

      <div className="ml-auto flex items-center gap-2 sm:gap-3">
        <div
          className={cn(
            "hidden items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold sm:flex",
            whatsappConfig.connected ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-brand-red"
          )}
        >
          {whatsappConfig.connected ? <Wifi className="h-3.5 w-3.5" /> : <WifiOff className="h-3.5 w-3.5" />}
          <span className="relative flex h-1.5 w-1.5">
            <span
              className={cn(
                "absolute inline-flex h-full w-full rounded-full opacity-75",
                whatsappConfig.connected ? "animate-ping bg-emerald-500" : "bg-brand-red"
              )}
            />
            <span className={cn("relative inline-flex h-1.5 w-1.5 rounded-full", whatsappConfig.connected ? "bg-emerald-500" : "bg-brand-red")} />
          </span>
          {whatsappConfig.connected ? "Connected" : "Disconnected"}
          <span className="hidden text-neutral-400 lg:inline">· WhatsApp Business API</span>
        </div>

        <div className="relative" ref={bellRef}>
          <button
            type="button"
            onClick={() => setBellOpen((v) => !v)}
            aria-label="Notifications"
            className="relative flex h-9 w-9 items-center justify-center rounded-lg text-neutral-500 hover:bg-neutral-100"
          >
            <Bell className="h-[18px] w-[18px]" />
            {unread > 0 && (
              <span className="absolute right-1.5 top-1.5 flex h-2 w-2 rounded-full bg-brand-red ring-2 ring-white" />
            )}
          </button>
          <AnimatePresence>
            {bellOpen && (
              <motion.div
                initial={{ opacity: 0, y: -8, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -8, scale: 0.97 }}
                transition={{ duration: 0.15 }}
                className="absolute right-0 top-11 z-30 w-80 overflow-hidden rounded-2xl border border-black/8 bg-white shadow-2xl"
              >
                <div className="flex items-center justify-between border-b border-black/8 px-4 py-3">
                  <p className="text-sm font-bold text-neutral-900">Notifications</p>
                  <Link href="/master-admin/notifications" onClick={() => setBellOpen(false)} className="text-xs font-semibold text-brand-red">
                    View all
                  </Link>
                </div>
                <ul className="max-h-80 overflow-y-auto">
                  {notificationsStore.slice(0, 5).map((n) => (
                    <li key={n.id} className="border-b border-black/5 px-4 py-3 last:border-0 hover:bg-neutral-50">
                      <div className="flex items-start gap-2">
                        {!n.read && <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-red" />}
                        <div className={cn("min-w-0", n.read && "pl-3.5")}>
                          <p className="truncate text-xs font-bold text-neutral-800">{n.title}</p>
                          <p className="mt-0.5 line-clamp-1 text-xs text-neutral-500">{n.description}</p>
                          <p className="mt-1 text-[11px] text-neutral-400">{timeAgo(n.timestamp)}</p>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <Link href="/master-admin/settings" className="flex items-center gap-2 rounded-lg py-1 pl-1 pr-2 hover:bg-neutral-100">
          <span
            className="flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold text-white"
            style={{ backgroundColor: currentAdmin.avatarColor }}
          >
            {currentAdmin.name.split(" ").map((n) => n[0]).join("")}
          </span>
          <span className="hidden text-left sm:block">
            <span className="block text-xs font-bold leading-tight text-neutral-800">{currentAdmin.name.split(" ")[0]}</span>
            <span className="block text-[11px] leading-tight text-neutral-400">Master Admin</span>
          </span>
        </Link>
      </div>
    </header>
  );
}
