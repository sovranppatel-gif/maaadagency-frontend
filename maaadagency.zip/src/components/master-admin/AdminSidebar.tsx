"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "motion/react";
import { LogOut, X } from "lucide-react";
import { adminNavItems } from "@/lib/admin-nav";
import { currentAdmin } from "@/lib/mock-data/settings";
import { cn } from "@/lib/utils";

function NavList({ pathname, onNavigate }: { pathname: string; onNavigate?: () => void }) {
  return (
    <ul className="flex flex-col gap-0.5 px-3">
      {adminNavItems.map((item) => {
        const active = item.href === "/master-admin" ? pathname === item.href : pathname.startsWith(item.href);
        return (
          <li key={item.href} className="relative">
            <Link
              href={item.href}
              onClick={onNavigate}
              className={cn(
                "relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition-colors",
                active ? "text-brand-red" : "text-neutral-400 hover:bg-white/5 hover:text-neutral-200"
              )}
            >
              {active && (
                <motion.span
                  layoutId="admin-nav-active"
                  className="absolute inset-0 rounded-xl bg-brand-red/10 ring-1 ring-inset ring-brand-red/20"
                  transition={{ type: "spring", stiffness: 400, damping: 32 }}
                />
              )}
              <item.icon className="relative z-10 h-[18px] w-[18px] shrink-0" strokeWidth={2.25} />
              <span className="relative z-10">{item.label}</span>
              {active && <span className="absolute right-2 top-1/2 z-10 h-1.5 w-1.5 -translate-y-1/2 rounded-full bg-brand-red" />}
            </Link>
          </li>
        );
      })}
    </ul>
  );
}

function ProfileBlock() {
  return (
    <div className="border-t border-white/8 p-3">
      <div className="flex items-center gap-3 rounded-xl px-2 py-2">
        <span
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-bold text-white"
          style={{ backgroundColor: currentAdmin.avatarColor }}
        >
          {currentAdmin.name
            .split(" ")
            .map((n) => n[0])
            .join("")}
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-bold text-white">{currentAdmin.name}</p>
          <p className="truncate text-[11px] text-neutral-400">Master Admin</p>
        </div>
        <button
          type="button"
          aria-label="Log out"
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-neutral-400 transition-colors hover:bg-white/5 hover:text-brand-red"
        >
          <LogOut className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

export function AdminSidebar({ mobileOpen, onMobileClose }: { mobileOpen: boolean; onMobileClose: () => void }) {
  const pathname = usePathname();

  return (
    <>
      {/* Desktop */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[260px] flex-col bg-[#111111] lg:flex">
        <div className="flex h-16 items-center gap-2.5 border-b border-white/8 px-5">
          <Image src="/images/logo.png" alt="Maa Ad Agency" width={130} height={58} className="h-8 w-auto" priority />
          <span className="rounded-md bg-white/10 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-neutral-300">
            Admin
          </span>
        </div>
        <nav className="flex-1 overflow-y-auto py-4">
          <NavList pathname={pathname} />
        </nav>
        <ProfileBlock />
      </aside>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <div className="fixed inset-0 z-[140] lg:hidden">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onMobileClose}
              className="absolute inset-0 bg-black/60"
            />
            <motion.aside
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", stiffness: 320, damping: 34 }}
              className="relative flex h-full w-[280px] flex-col bg-[#111111]"
            >
              <div className="flex h-16 items-center justify-between gap-2.5 border-b border-white/8 px-5">
                <Image src="/images/logo.png" alt="Maa Ad Agency" width={130} height={58} className="h-8 w-auto" />
                <button
                  type="button"
                  onClick={onMobileClose}
                  aria-label="Close menu"
                  className="flex h-8 w-8 items-center justify-center rounded-lg text-neutral-400 hover:bg-white/5 hover:text-white"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <nav className="flex-1 overflow-y-auto py-4">
                <NavList pathname={pathname} onNavigate={onMobileClose} />
              </nav>
              <ProfileBlock />
            </motion.aside>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
