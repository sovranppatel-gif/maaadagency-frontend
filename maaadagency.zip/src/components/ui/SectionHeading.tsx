import { cn } from "@/lib/utils";
import { Reveal } from "./Reveal";

export function SectionHeading({
  eyebrow,
  title,
  highlight,
  subtitle,
  align = "left",
  tone = "dark",
  className,
}: {
  eyebrow?: string;
  title: string;
  highlight?: string;
  subtitle?: string;
  align?: "left" | "center";
  tone?: "dark" | "light";
  className?: string;
}) {
  const parts = highlight ? title.split(highlight) : [title];

  return (
    <div
      className={cn(
        "max-w-2xl",
        align === "center" && "mx-auto text-center",
        className
      )}
    >
      {eyebrow && (
        <Reveal>
          <span
            className={cn(
              "mb-4 inline-flex items-center gap-2 rounded-full border px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em]",
              tone === "dark"
                ? "border-black/10 bg-brand-gray text-brand-red"
                : "border-white/15 bg-white/5 text-white/80"
            )}
          >
            <span className="h-1.5 w-1.5 rounded-full bg-brand-red" />
            {eyebrow}
          </span>
        </Reveal>
      )}
      <Reveal delay={0.08}>
        <h2
          className={cn(
            "font-display text-4xl font-extrabold leading-[1.05] tracking-tight text-balance sm:text-5xl",
            tone === "dark" ? "text-brand-dark" : "text-white"
          )}
        >
          {parts[0]}
          {highlight && <span className="text-brand-red">{highlight}</span>}
          {parts[1]}
        </h2>
      </Reveal>
      {subtitle && (
        <Reveal delay={0.16}>
          <p
            className={cn(
              "mt-5 text-lg leading-relaxed",
              tone === "dark" ? "text-black/60" : "text-white/65"
            )}
          >
            {subtitle}
          </p>
        </Reveal>
      )}
    </div>
  );
}
