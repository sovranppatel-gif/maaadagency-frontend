"use client";

import { useEffect, useState } from "react";
import { useReducedMotion } from "motion/react";
import { useInViewOnce } from "@/lib/useInViewOnce";

// Cubic ease-out, matches the rest of the site's motion feel.
function easeOutCubic(t: number) {
  return 1 - Math.pow(1 - t, 3);
}

export function AnimatedCounter({
  value,
  suffix = "",
  duration = 1.6,
  className,
}: {
  value: number;
  suffix?: string;
  duration?: number;
  className?: string;
}) {
  const shouldReduceMotion = useReducedMotion();
  const { ref, inView } = useInViewOnce<HTMLSpanElement>("-60px");
  const [display, setDisplay] = useState(0);

  // Deliberately only depends on `inView`: once the animation starts it must
  // run to completion. Re-running on every `shouldReduceMotion` update (that
  // hook can settle from null -> false shortly after mount) would cancel an
  // in-flight animation frame and leave the counter stuck.
  useEffect(() => {
    if (!inView) return;

    if (shouldReduceMotion) {
      const id = requestAnimationFrame(() => setDisplay(value));
      return () => cancelAnimationFrame(id);
    }

    let frame: number;
    const start = performance.now();
    const durationMs = duration * 1000;

    const tick = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / durationMs, 1);
      setDisplay(Math.round(easeOutCubic(progress) * value));
      if (progress < 1) {
        frame = requestAnimationFrame(tick);
      }
    };

    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inView]);

  return (
    <span ref={ref} className={className}>
      {display}
      {suffix}
    </span>
  );
}
