"use client";

import { motion, useReducedMotion, type Variants } from "motion/react";
import { fadeUp, withDelay } from "@/lib/motion";
import { useInViewOnce } from "@/lib/useInViewOnce";

type RevealProps = {
  children: React.ReactNode;
  variants?: Variants;
  className?: string;
  delay?: number;
};

/** Generic scroll-reveal wrapper. Disables motion when the user prefers reduced motion. */
export function Reveal({ children, variants = fadeUp, className, delay = 0 }: RevealProps) {
  const shouldReduceMotion = useReducedMotion();
  const { ref, inView } = useInViewOnce<HTMLDivElement>();

  if (shouldReduceMotion) {
    return <div className={className}>{children}</div>;
  }

  return (
    <motion.div
      ref={ref}
      initial="hidden"
      animate={inView ? "show" : "hidden"}
      variants={delay ? withDelay(variants, delay) : variants}
      className={className}
    >
      {children}
    </motion.div>
  );
}
