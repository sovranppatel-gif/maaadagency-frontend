import { Phone } from "lucide-react";
import { site } from "@/data/site";
import { telHref } from "@/lib/utils";

export function MobileStickyBar() {
  return (
    <div
      className="fixed inset-x-0 bottom-0 z-40 flex items-stretch gap-2.5 border-t border-black/10 bg-white/95 p-3 backdrop-blur-xl sm:hidden"
      style={{ paddingBottom: "calc(0.75rem + env(safe-area-inset-bottom))" }}
    >
      <a
        href={telHref(site.phones[0])}
        className="flex flex-1 items-center justify-center gap-2 rounded-full border-2 border-brand-dark px-4 py-3 text-sm font-bold text-brand-dark"
      >
        <Phone className="h-4 w-4" />
        Call Now
      </a>
      <a
        href="#contact"
        className="flex flex-1 items-center justify-center gap-2 rounded-full bg-brand-red px-4 py-3 text-sm font-bold text-white shadow-lg shadow-brand-red/25"
      >
        Start a Project
      </a>
    </div>
  );
}
