import Image from "next/image";
import { Phone, Mail, Globe, MapPin } from "lucide-react";
import { site, navLinks } from "@/data/site";
import { telHref } from "@/lib/utils";
import { Container } from "@/components/ui/Container";
import {
  InstagramIcon,
  FacebookIcon,
  LinkedInIcon,
  YouTubeIcon,
} from "@/components/ui/SocialIcons";

const footerServices = [
  "Print Media",
  "Outdoor Advertising",
  "Digital Marketing",
  "LED Screens",
  "Event Management",
  "Corporate Gifting",
];

const socialLinks = [
  { Icon: InstagramIcon, href: site.social.instagram, label: "Instagram" },
  { Icon: FacebookIcon, href: site.social.facebook, label: "Facebook" },
  { Icon: LinkedInIcon, href: site.social.linkedin, label: "LinkedIn" },
  { Icon: YouTubeIcon, href: site.social.youtube, label: "YouTube" },
];

export function Footer() {
  return (
    <footer className="bg-brand-dark text-white">
      <Container className="py-16 sm:py-20">
        <div className="grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <Image
              src="/images/logo.png"
              alt={`${site.name} logo`}
              width={160}
              height={71}
              className="h-12 w-auto"
            />
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-white/55">
              A complete advertising and branding company helping businesses
              grow through creativity, strategy and powerful media solutions
              since 2010.
            </p>
            <div className="mt-6 flex items-center gap-3">
              {socialLinks.map(({ Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="flex h-10 w-10 items-center justify-center rounded-full border border-white/15 text-white/70 transition-colors hover:border-brand-red hover:bg-brand-red hover:text-white"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-display text-sm font-bold uppercase tracking-[0.15em] text-white/90">
              Quick Links
            </h3>
            <ul className="mt-5 space-y-3">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-sm text-white/55 transition-colors hover:text-brand-red"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-display text-sm font-bold uppercase tracking-[0.15em] text-white/90">
              Our Services
            </h3>
            <ul className="mt-5 space-y-3">
              {footerServices.map((s) => (
                <li key={s} className="text-sm text-white/55">
                  {s}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-display text-sm font-bold uppercase tracking-[0.15em] text-white/90">
              Contact Us
            </h3>
            <ul className="mt-5 space-y-4 text-sm text-white/55">
              <li className="flex items-start gap-3">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brand-red" />
                <span>
                  {site.address.line1}
                  <br />
                  {site.address.line2}
                </span>
              </li>
              <li className="flex flex-col gap-1.5">
                {site.phones.map((phone) => (
                  <a
                    key={phone}
                    href={telHref(phone)}
                    className="flex items-center gap-3 transition-colors hover:text-brand-red"
                  >
                    <Phone className="h-4 w-4 shrink-0 text-brand-red" />
                    +91 {phone}
                  </a>
                ))}
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-4 w-4 shrink-0 text-brand-red" />
                <a href={`mailto:${site.email}`} className="transition-colors hover:text-brand-red">
                  {site.email}
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Globe className="h-4 w-4 shrink-0 text-brand-red" />
                <a
                  href={site.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="transition-colors hover:text-brand-red"
                >
                  {site.website}
                </a>
              </li>
            </ul>
          </div>
        </div>
      </Container>

      <div className="border-t border-white/10">
        <Container className="flex flex-col items-center gap-2 py-6 text-xs text-white/45 sm:flex-row sm:justify-between">
          <p>© 2026 {site.name}. All Rights Reserved.</p>
          <p>Ideas Today. A Stronger Tomorrow.</p>
        </Container>
      </div>
    </footer>
  );
}
