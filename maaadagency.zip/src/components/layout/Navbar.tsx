"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { motion } from "motion/react";
import { Phone, Menu } from "lucide-react";
import { navLinks, site } from "@/data/site";
import { telHref, cn } from "@/lib/utils";
import { MobileMenu } from "./MobileMenu";

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [activeId, setActiveId] = useState("home");
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    function onScroll() {
      setScrolled(window.scrollY > 24);
    }
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const ids = navLinks.map((l) => l.href.replace("#", ""));
    const sections = ids
      .map((id) => document.getElementById(id))
      .filter((el): el is HTMLElement => Boolean(el));

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveId(entry.target.id);
          }
        });
      },
      { rootMargin: "-40% 0px -50% 0px", threshold: 0 }
    );

    sections.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-all duration-500",
          scrolled || menuOpen
            ? "bg-white/80 shadow-[0_1px_0_0_rgba(0,0,0,0.06),0_10px_30px_-15px_rgba(0,0,0,0.15)] backdrop-blur-xl"
            : "bg-transparent"
        )}
      >
        <nav className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5 sm:px-8 lg:px-10">
          <a href="#home" className="relative z-10 flex items-center" aria-label={site.name}>
            <Image
              src="/images/logo.png"
              alt={`${site.name} logo`}
              width={168}
              height={75}
              priority
              className="h-11 w-auto sm:h-12"
            />
          </a>

          <ul className="hidden items-center gap-1 lg:flex">
            {navLinks.map((link) => {
              const isActive = activeId === link.href.replace("#", "");
              return (
                <li key={link.href} className="relative">
                  <a
                    href={link.href}
                    className={cn(
                      "relative block px-4 py-2 text-sm font-semibold transition-colors",
                      isActive
                        ? "text-brand-red"
                        : scrolled
                        ? "text-brand-dark/80 hover:text-brand-red"
                        : "text-brand-dark/90 hover:text-brand-red"
                    )}
                  >
                    {link.label}
                    {isActive && (
                      <motion.span
                        layoutId="nav-active-indicator"
                        className="absolute inset-x-3 -bottom-0.5 h-0.5 rounded-full bg-brand-red"
                        transition={{ type: "spring", stiffness: 400, damping: 30 }}
                      />
                    )}
                  </a>
                </li>
              );
            })}
          </ul>

          <div className="hidden items-center gap-5 lg:flex">
            <a
              href={telHref(site.phones[0])}
              className={cn(
                "flex items-center gap-2 text-sm font-semibold transition-colors",
                scrolled ? "text-brand-dark/80" : "text-brand-dark/90",
                "hover:text-brand-red"
              )}
            >
              <Phone className="h-4 w-4 text-brand-red" strokeWidth={2.5} />
              +91 {site.phones[0]}
            </a>
            <a
              href="#contact"
              className="group relative inline-flex items-center overflow-hidden rounded-full bg-brand-red px-6 py-2.5 text-sm font-bold text-white shadow-lg shadow-brand-red/25 transition-transform hover:scale-[1.03] active:scale-[0.98]"
            >
              Start a Project
            </a>
          </div>

          <button
            type="button"
            onClick={() => setMenuOpen(true)}
            className="relative z-10 flex h-11 w-11 items-center justify-center rounded-full border border-black/10 text-brand-dark lg:hidden"
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>
        </nav>
      </header>

      <MobileMenu open={menuOpen} onClose={() => setMenuOpen(false)} activeId={activeId} />
    </>
  );
}
