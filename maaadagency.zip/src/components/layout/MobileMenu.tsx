"use client";

import { useEffect } from "react";
import Image from "next/image";
import { AnimatePresence, motion } from "motion/react";
import { X, Phone } from "lucide-react";
import { navLinks, site } from "@/data/site";
import { telHref, cn } from "@/lib/utils";
import {
  InstagramIcon,
  FacebookIcon,
  LinkedInIcon,
  YouTubeIcon,
} from "@/components/ui/SocialIcons";

export function MobileMenu({
  open,
  onClose,
  activeId,
}: {
  open: boolean;
  onClose: () => void;
  activeId: string;
}) {
  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 z-[60] bg-brand-dark text-white lg:hidden"
        >
          <div className="flex h-20 items-center justify-between px-5 sm:px-8">
            <Image
              src="/images/logo.png"
              alt={`${site.name} logo`}
              width={140}
              height={62}
              className="h-10 w-auto"
            />
            <button
              type="button"
              onClick={onClose}
              aria-label="Close menu"
              className="flex h-11 w-11 items-center justify-center rounded-full border border-white/15"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <nav className="flex flex-col px-5 pt-6 sm:px-8">
            {navLinks.map((link, i) => (
              <motion.a
                key={link.href}
                href={link.href}
                onClick={onClose}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.08 + i * 0.06, duration: 0.4 }}
                className={cn(
                  "border-b border-white/10 py-4 font-display text-3xl font-bold tracking-tight",
                  activeId === link.href.replace("#", "") ? "text-brand-red" : "text-white"
                )}
              >
                {link.label}
              </motion.a>
            ))}
          </nav>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.4 }}
            className="mt-8 flex flex-col gap-4 px-5 sm:px-8"
          >
            <a
              href="#contact"
              onClick={onClose}
              className="inline-flex items-center justify-center rounded-full bg-brand-red px-6 py-3.5 text-center text-sm font-bold text-white"
            >
              Start a Project
            </a>
            {site.phones.map((phone) => (
              <a
                key={phone}
                href={telHref(phone)}
                className="flex items-center gap-2 text-sm font-semibold text-white/80"
              >
                <Phone className="h-4 w-4 text-brand-red" />
                +91 {phone}
              </a>
            ))}
            <div className="mt-2 flex items-center gap-4">
              {[
                { Icon: InstagramIcon, href: site.social.instagram, label: "Instagram" },
                { Icon: FacebookIcon, href: site.social.facebook, label: "Facebook" },
                { Icon: LinkedInIcon, href: site.social.linkedin, label: "LinkedIn" },
                { Icon: YouTubeIcon, href: site.social.youtube, label: "YouTube" },
              ].map(({ Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="flex h-10 w-10 items-center justify-center rounded-full border border-white/15 text-white/70"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
