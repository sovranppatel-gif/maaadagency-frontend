import type { Transition, Variants } from "motion/react";

// Shared, reusable Framer Motion variants for consistent, professional
// animation across the site. Kept subtle and purposeful per the brief.

export const easeOut: Transition["ease"] = [0.16, 1, 0.3, 1];

export const fadeUp: Variants = {
  hidden: { opacity: 0, y: 28 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: easeOut },
  },
};

export const scaleIn: Variants = {
  hidden: { opacity: 0, scale: 0.92 },
  show: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.7, ease: easeOut },
  },
};

export const staggerContainer = (
  stagger = 0.12,
  delayChildren = 0
): Variants => ({
  hidden: {},
  show: {
    transition: {
      staggerChildren: stagger,
      delayChildren,
    },
  },
});

export function withDelay(variants: Variants, delay: number): Variants {
  const show = variants.show;
  if (!show || typeof show !== "object") return variants;
  const showTransition =
    "transition" in show && show.transition ? show.transition : {};
  return {
    ...variants,
    show: {
      ...show,
      transition: { ...showTransition, delay },
    },
  };
}
