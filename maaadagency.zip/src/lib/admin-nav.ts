import {
  LayoutDashboard,
  Inbox,
  ClipboardList,
  MessageCircle,
  Users,
  Building2,
  FolderKanban,
  Layers,
  FileText,
  Bell,
  BarChart3,
  Settings,
  type LucideIcon,
} from "lucide-react";

export interface AdminNavItem {
  label: string;
  href: string;
  icon: LucideIcon;
}

export const adminNavItems: AdminNavItem[] = [
  { label: "Dashboard", href: "/master-admin", icon: LayoutDashboard },
  { label: "Leads", href: "/master-admin/leads", icon: Inbox },
  { label: "Work Management", href: "/master-admin/work", icon: ClipboardList },
  { label: "WhatsApp Inbox", href: "/master-admin/whatsapp", icon: MessageCircle },
  { label: "Employees", href: "/master-admin/employees", icon: Users },
  { label: "Clients", href: "/master-admin/clients", icon: Building2 },
  { label: "Projects", href: "/master-admin/projects", icon: FolderKanban },
  { label: "Services", href: "/master-admin/services", icon: Layers },
  { label: "Files & Reports", href: "/master-admin/files", icon: FileText },
  { label: "Notifications", href: "/master-admin/notifications", icon: Bell },
  { label: "Analytics", href: "/master-admin/analytics", icon: BarChart3 },
  { label: "Settings", href: "/master-admin/settings", icon: Settings },
];

export function getPageTitle(pathname: string): string {
  if (pathname === "/master-admin") return "Dashboard";
  const match = adminNavItems.find((i) => i.href !== "/master-admin" && pathname.startsWith(i.href));
  if (match) return match.label;
  if (pathname.includes("/leads/")) return "Lead Details";
  if (pathname.includes("/work/")) return "Work Details";
  if (pathname.includes("/employees/")) return "Employee Profile";
  if (pathname.includes("/clients/")) return "Client Profile";
  if (pathname.includes("/projects/")) return "Project Details";
  return "Master Admin";
}
