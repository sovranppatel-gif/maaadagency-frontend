import { files as filesStore } from "@/lib/mock-data/files";
import type { FileCategory, FileRecord } from "@/lib/types";
import { delay } from "./utils";

export async function getFiles(category: FileCategory | "All" = "All", search = ""): Promise<FileRecord[]> {
  let result = [...filesStore];
  if (category !== "All") result = result.filter((f) => f.category === category);
  if (search) {
    const q = search.toLowerCase();
    result = result.filter(
      (f) => f.name.toLowerCase().includes(q) || (f.clientName || "").toLowerCase().includes(q) || (f.projectName || "").toLowerCase().includes(q)
    );
  }
  result.sort((a, b) => +new Date(b.uploadedAt) - +new Date(a.uploadedAt));
  return delay(result);
}
