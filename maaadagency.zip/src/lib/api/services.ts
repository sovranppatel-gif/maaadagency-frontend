import { services as servicesStore, getServiceById } from "@/lib/mock-data/services";
import type { ServiceItem } from "@/lib/types";
import { delay, newId } from "./utils";

export async function getServices(): Promise<ServiceItem[]> {
  return delay([...servicesStore]);
}

export async function toggleServiceStatus(id: string): Promise<ServiceItem | undefined> {
  const svc = getServiceById(id);
  if (!svc) return delay(undefined);
  svc.status = svc.status === "Active" ? "Disabled" : "Active";
  return delay({ ...svc });
}

export async function createService(data: Partial<ServiceItem>): Promise<ServiceItem> {
  const svc: ServiceItem = {
    id: newId("svc"),
    name: data.name ?? "New Service",
    description: data.description ?? "",
    icon: data.icon ?? "Sparkles",
    status: "Active",
    leadsCount: 0,
  };
  servicesStore.push(svc);
  return delay(svc);
}

export async function deleteService(id: string): Promise<boolean> {
  const idx = servicesStore.findIndex((s) => s.id === id);
  if (idx >= 0) servicesStore.splice(idx, 1);
  return delay(true);
}
