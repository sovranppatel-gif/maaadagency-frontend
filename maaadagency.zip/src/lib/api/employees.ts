import { employees as employeesStore, getEmployeeById } from "@/lib/mock-data/employees";
import type { Availability, Employee } from "@/lib/types";
import { delay } from "./utils";

export async function getEmployees(): Promise<Employee[]> {
  return delay([...employeesStore]);
}

export async function getEmployee(id: string): Promise<Employee | undefined> {
  return delay(getEmployeeById(id));
}

export async function updateEmployeeAvailability(id: string, availability: Availability): Promise<Employee | undefined> {
  const emp = getEmployeeById(id);
  if (!emp) return delay(undefined);
  emp.availability = availability;
  return delay({ ...emp });
}
