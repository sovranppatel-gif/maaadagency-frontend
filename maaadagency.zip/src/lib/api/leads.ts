// Lead API abstraction. Backed by in-memory mock data for now.
// Replace the function bodies with `fetch("/api/leads", ...)` calls once the
// Node/Express + MongoDB backend is available — signatures are designed to
// stay stable across that swap.

import { leads as leadsStore, getLeadById } from "@/lib/mock-data/leads";
import type { Lead, LeadStatus, Priority } from "@/lib/types";
import { delay, newId, nowIso } from "./utils";

export interface LeadFilters {
  search?: string;
  service?: string;
  status?: LeadStatus | "All";
  priority?: Priority | "All";
  employeeId?: string | "All";
  source?: string | "All";
}

export async function getLeads(filters: LeadFilters = {}): Promise<Lead[]> {
  let result = [...leadsStore];

  if (filters.search) {
    const q = filters.search.toLowerCase();
    result = result.filter(
      (l) =>
        l.clientName.toLowerCase().includes(q) ||
        l.id.toLowerCase().includes(q) ||
        l.requirement.toLowerCase().includes(q) ||
        l.phone.includes(q)
    );
  }
  if (filters.service && filters.service !== "All") {
    result = result.filter((l) => l.service === filters.service);
  }
  if (filters.status && filters.status !== "All") {
    result = result.filter((l) => l.status === filters.status);
  }
  if (filters.priority && filters.priority !== "All") {
    result = result.filter((l) => l.priority === filters.priority);
  }
  if (filters.employeeId && filters.employeeId !== "All") {
    result = result.filter((l) => l.assignedEmployeeId === filters.employeeId);
  }
  if (filters.source && filters.source !== "All") {
    result = result.filter((l) => l.source === filters.source);
  }

  result.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
  return delay(result);
}

export async function getLead(id: string): Promise<Lead | undefined> {
  return delay(getLeadById(id));
}

export async function assignLead(id: string, employeeId: string): Promise<Lead | undefined> {
  const lead = getLeadById(id);
  if (!lead) return delay(undefined);
  lead.assignedEmployeeId = employeeId;
  lead.assignedDate = nowIso();
  lead.status = "Assigned";
  lead.updatedAt = nowIso();
  lead.activity.push({ id: newId("act"), label: "Assigned to employee", timestamp: nowIso(), actor: "Admin" });
  return delay({ ...lead });
}

export async function updateLeadStatus(id: string, status: LeadStatus): Promise<Lead | undefined> {
  const lead = getLeadById(id);
  if (!lead) return delay(undefined);
  lead.status = status;
  lead.updatedAt = nowIso();
  lead.activity.push({ id: newId("act"), label: `Status changed to ${status}`, timestamp: nowIso(), actor: "Admin" });
  return delay({ ...lead });
}

export async function createLead(data: Partial<Lead>): Promise<Lead> {
  const lead: Lead = {
    id: newId("LD"),
    clientId: data.clientId ?? newId("cl"),
    clientName: data.clientName ?? "New Client",
    phone: data.phone ?? "",
    company: data.company,
    email: data.email,
    service: data.service ?? "Other",
    requirement: data.requirement ?? "",
    description: data.description ?? "",
    referenceWebsite: data.referenceWebsite,
    deadline: data.deadline,
    budget: data.budget,
    source: data.source ?? "Manual",
    priority: data.priority ?? "MEDIUM",
    status: "New",
    assignedEmployeeId: undefined,
    attachments: [],
    activity: [{ id: newId("act"), label: "Lead Created", timestamp: nowIso(), actor: "Admin" }],
    createdAt: nowIso(),
    updatedAt: nowIso(),
  };
  leadsStore.unshift(lead);
  return delay(lead);
}

export async function deleteLead(id: string): Promise<boolean> {
  const idx = leadsStore.findIndex((l) => l.id === id);
  if (idx >= 0) leadsStore.splice(idx, 1);
  return delay(true);
}
