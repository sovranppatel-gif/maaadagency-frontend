import { whatsappConfig, currentAdmin } from "@/lib/mock-data/settings";
import type { WhatsAppApiConfig } from "@/lib/types";
import { delay } from "./utils";

export async function getWhatsAppConfig(): Promise<WhatsAppApiConfig> {
  return delay({ ...whatsappConfig });
}

export async function saveWhatsAppConfig(partial: Partial<WhatsAppApiConfig>): Promise<WhatsAppApiConfig> {
  Object.assign(whatsappConfig, partial);
  return delay({ ...whatsappConfig }, 500);
}

export async function testWhatsAppConnection(): Promise<{ success: boolean; message: string }> {
  return delay(
    whatsappConfig.connected
      ? { success: true, message: "Connection successful. Webhook is verified and reachable." }
      : { success: false, message: "Could not reach WhatsApp Business API. Check your credentials." },
    900
  );
}

export async function getCurrentAdmin() {
  return delay({ ...currentAdmin }, 100);
}
