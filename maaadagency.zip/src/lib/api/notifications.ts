import { notifications as notificationsStore } from "@/lib/mock-data/notifications";
import type { AppNotification, NotificationCategory } from "@/lib/types";
import { delay } from "./utils";

export async function getNotifications(category: NotificationCategory | "All" = "All", unreadOnly = false): Promise<AppNotification[]> {
  let result = [...notificationsStore];
  if (category !== "All") result = result.filter((n) => n.category === category);
  if (unreadOnly) result = result.filter((n) => !n.read);
  result.sort((a, b) => +new Date(b.timestamp) - +new Date(a.timestamp));
  return delay(result);
}

export async function markAllRead(): Promise<void> {
  notificationsStore.forEach((n) => (n.read = true));
  return delay(undefined, 100);
}

export async function markRead(id: string): Promise<void> {
  const n = notificationsStore.find((n) => n.id === id);
  if (n) n.read = true;
  return delay(undefined, 50);
}

export function unreadCount() {
  return notificationsStore.filter((n) => !n.read).length;
}
