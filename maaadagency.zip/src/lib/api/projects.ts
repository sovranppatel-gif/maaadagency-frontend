import { projects as projectsStore, getProjectById } from "@/lib/mock-data/projects";
import type { Project } from "@/lib/types";
import { delay } from "./utils";

export async function getProjects(): Promise<Project[]> {
  return delay([...projectsStore]);
}

export async function getProject(id: string): Promise<Project | undefined> {
  return delay(getProjectById(id));
}
