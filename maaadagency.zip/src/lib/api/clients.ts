import { clients as clientsStore, getClientById } from "@/lib/mock-data/clients";
import type { Client } from "@/lib/types";
import { delay } from "./utils";

export async function getClients(): Promise<Client[]> {
  return delay([...clientsStore]);
}

export async function getClient(id: string): Promise<Client | undefined> {
  return delay(getClientById(id));
}
