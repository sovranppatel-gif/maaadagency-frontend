// Work API abstraction — see lib/api/leads.ts for the swap-to-real-backend note.

import { works as worksStore, getWorkById } from "@/lib/mock-data/works";
import type { Priority, RevisionRequest, Work, WorkStatus } from "@/lib/types";
import { delay, newId, nowIso } from "./utils";

export interface WorkFilters {
  search?: string;
  status?: WorkStatus | "All";
  priority?: Priority | "All";
  employeeId?: string | "All";
}

export async function getWorks(filters: WorkFilters = {}): Promise<Work[]> {
  let result = [...worksStore];

  if (filters.search) {
    const q = filters.search.toLowerCase();
    result = result.filter(
      (w) => w.title.toLowerCase().includes(q) || w.clientName.toLowerCase().includes(q) || w.id.toLowerCase().includes(q)
    );
  }
  if (filters.status && filters.status !== "All") {
    result = result.filter((w) => w.status === filters.status);
  }
  if (filters.priority && filters.priority !== "All") {
    result = result.filter((w) => w.priority === filters.priority);
  }
  if (filters.employeeId && filters.employeeId !== "All") {
    result = result.filter((w) => w.employeeId === filters.employeeId);
  }

  result.sort((a, b) => +new Date(b.updatedAt) - +new Date(a.updatedAt));
  return delay(result);
}

export async function getWork(id: string): Promise<Work | undefined> {
  return delay(getWorkById(id));
}

export async function createWork(data: Partial<Work>): Promise<Work> {
  const work: Work = {
    id: newId("WK"),
    leadId: data.leadId,
    clientId: data.clientId ?? "",
    clientName: data.clientName ?? "New Client",
    employeeId: data.employeeId,
    title: data.title ?? "Untitled Work",
    description: data.description ?? "",
    service: data.service ?? "Other",
    priority: data.priority ?? "MEDIUM",
    deadline: data.deadline ?? nowIso(),
    status: data.employeeId ? "ASSIGNED" : "UNASSIGNED",
    progress: 0,
    attachments: [],
    revisionHistory: [],
    activity: [{ id: newId("act"), label: "Work Created", timestamp: nowIso(), actor: "Admin" }],
    createdAt: nowIso(),
    updatedAt: nowIso(),
  };
  worksStore.unshift(work);
  return delay(work);
}

export async function assignWork(id: string, employeeId: string): Promise<Work | undefined> {
  const work = getWorkById(id);
  if (!work) return delay(undefined);
  work.employeeId = employeeId;
  work.status = "ASSIGNED";
  work.updatedAt = nowIso();
  work.activity.push({ id: newId("act"), label: "Assigned to employee", timestamp: nowIso(), actor: "Admin" });
  return delay({ ...work });
}

export async function approveWork(id: string): Promise<Work | undefined> {
  const work = getWorkById(id);
  if (!work) return delay(undefined);
  work.status = "APPROVED";
  work.updatedAt = nowIso();
  work.activity.push({ id: newId("act"), label: "Work Approved", timestamp: nowIso(), actor: "Admin" });
  return delay({ ...work });
}

export async function requestRevision(
  id: string,
  notes: string,
  priority: Priority,
  deadline?: string
): Promise<Work | undefined> {
  const work = getWorkById(id);
  if (!work) return delay(undefined);
  const revision: RevisionRequest = { id: newId("rev"), notes, priority, deadline, requestedAt: nowIso() };
  work.revisionHistory.push(revision);
  work.status = "CHANGES_REQUESTED";
  work.priority = priority;
  if (deadline) work.deadline = deadline;
  work.updatedAt = nowIso();
  work.activity.push({ id: newId("act"), label: "Changes Requested", timestamp: nowIso(), actor: "Admin" });
  return delay({ ...work });
}

export async function markCompleted(id: string): Promise<Work | undefined> {
  const work = getWorkById(id);
  if (!work) return delay(undefined);
  work.status = "COMPLETED";
  work.progress = 100;
  work.updatedAt = nowIso();
  work.activity.push({ id: newId("act"), label: "Marked Completed", timestamp: nowIso(), actor: "Admin" });
  return delay({ ...work });
}

export async function updateWorkProgress(id: string, progress: number): Promise<Work | undefined> {
  const work = getWorkById(id);
  if (!work) return delay(undefined);
  work.progress = progress;
  work.updatedAt = nowIso();
  return delay({ ...work });
}
