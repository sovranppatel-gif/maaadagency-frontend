import { conversations as conversationsStore, messages as messagesStore } from "@/lib/mock-data/whatsapp";
import type { ConversationFilter, WhatsAppConversation, WhatsAppMessage } from "@/lib/types";
import { delay, newId, nowIso } from "./utils";

export async function getConversations(filter: ConversationFilter = "All", search = ""): Promise<WhatsAppConversation[]> {
  let result = [...conversationsStore];
  if (filter === "Unread") {
    result = result.filter((c) => c.unreadCount > 0);
  } else if (filter !== "All") {
    result = result.filter((c) => c.status === filter);
  }
  if (search) {
    const q = search.toLowerCase();
    result = result.filter((c) => c.clientName.toLowerCase().includes(q) || c.phone.includes(q));
  }
  result.sort((a, b) => +new Date(b.lastMessageAt) - +new Date(a.lastMessageAt));
  return delay(result);
}

export async function getConversation(id: string): Promise<WhatsAppConversation | undefined> {
  return delay(conversationsStore.find((c) => c.id === id));
}

export async function getMessages(conversationId: string): Promise<WhatsAppMessage[]> {
  return delay(messagesStore.filter((m) => m.conversationId === conversationId));
}

export async function sendMessage(conversationId: string, text: string): Promise<WhatsAppMessage> {
  const msg: WhatsAppMessage = {
    id: newId("msg"),
    conversationId,
    direction: "outbound",
    message: text,
    messageType: "text",
    timestamp: nowIso(),
    status: "sent",
  };
  messagesStore.push(msg);
  const conv = conversationsStore.find((c) => c.id === conversationId);
  if (conv) {
    conv.lastMessage = text;
    conv.lastMessageAt = nowIso();
  }
  return delay(msg, 150);
}

export async function markConversationRead(conversationId: string): Promise<void> {
  const conv = conversationsStore.find((c) => c.id === conversationId);
  if (conv) conv.unreadCount = 0;
  return delay(undefined, 50);
}
